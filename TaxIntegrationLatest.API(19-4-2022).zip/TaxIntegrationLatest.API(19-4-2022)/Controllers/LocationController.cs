﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {
        private readonly IDataRepository<Location> _dataRepository;
        public LocationController(IDataRepository<Location> dataRepository)
        {
            _dataRepository = dataRepository;
        }
        
        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Location> location = _dataRepository.GetAll();
            return Ok(location);
        }
        
        [HttpGet("{id}", Name = "GetLocation")]
        public IActionResult Get(long id)
        {
            Location location = _dataRepository.Get(id);
            if (location == null)
            {
                return NotFound("The Location not found.");
            }
            return Ok(location);
        }
        
        [HttpPost]
        public IActionResult Post([FromBody] Location location)
        {
            if (location == null)
            {
                return BadRequest("Location is null.");
            }
            _dataRepository.Add(location);
            return CreatedAtRoute(
                  "GetLocation",
                  new { Id = location.Id },
                  location);
        }
        
        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Location location)
        {
            if (location == null)
            {
                return BadRequest("Location is null.");
            }
            Location locationToUpdate = _dataRepository.Get(id);
            if (locationToUpdate == null)
            {
                return NotFound("The Location not found.");
            }
            _dataRepository.Update(locationToUpdate, location);
            return NoContent();
        }
       
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Location location = _dataRepository.Get(id);
            if (location == null)
            {
                return NotFound("The Location not found.");
            }
            _dataRepository.Delete(location);
            return NoContent();
        }
    }
}
