﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {

        private readonly IDataRepository<Customers> _dataRepository;
        public CustomersController(IDataRepository<Customers> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Customers> customers = _dataRepository.GetAll();
            return Ok(customers);
        }

        [HttpGet("{id}", Name = "GetCustomerss")]
        public IActionResult Get(long id)
        {
            Customers customers = _dataRepository.Get(id);
            if (customers == null)
            {
                return NotFound("The Customers not found.");
            }
            return Ok(customers);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Customers customers)
        {
            if (customers == null)
            {
                return BadRequest("Customers is null.");
            }
            _dataRepository.Add(customers);
            return CreatedAtRoute(
                  "GetCustomerss",
                  new { Id = customers.Id },
                  customers);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Customers customers)
        {
            if (customers == null)
            {
                return BadRequest("Customers is null.");
            }
            Customers CustomersToUpdate = _dataRepository.Get(id);
            if (CustomersToUpdate == null)
            {
                return NotFound("The Customers not found.");
            }
            _dataRepository.Update(CustomersToUpdate, customers);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Customers customers = _dataRepository.Get(id);
            if (customers == null)
            {
                return NotFound("The Customers not found.");
            }
            _dataRepository.Delete(customers);
            return NoContent();
        }
    }
}
