﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IndustryTypeController : ControllerBase
    {
        private readonly IDataRepository<IndustryType> _dataRepository;
        public IndustryTypeController(IDataRepository<IndustryType> dataRepository)
        {
            _dataRepository = dataRepository;
        }
        
        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<IndustryType> industrytype = _dataRepository.GetAll();
            return Ok(industrytype);
        }
        
        [HttpGet("{id}", Name = "GetIndustryType")]
        public IActionResult Get(long id)
        {
            IndustryType industrytype = _dataRepository.Get(id);
            if (industrytype == null)
            {
                return NotFound("The Industry Types not found.");
            }
            return Ok(industrytype);
        }
        
        [HttpPost]
        public IActionResult Post([FromBody] IndustryType industrytype)
        {
            if (industrytype == null)
            {
                return BadRequest("IndustryType is null.");
            }
            _dataRepository.Add(industrytype);
            return CreatedAtRoute(
                  "GetIndustryType",
                  new { Id = industrytype.Id },
                  industrytype);
        }
        
        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] IndustryType industrytype)
        {
            if (industrytype == null)
            {
                return BadRequest("IndustryType is null.");
            }
            IndustryType industrytypeToUpdate = _dataRepository.Get(id);
            if (industrytypeToUpdate == null)
            {
                return NotFound("The IndustryType not found.");
            }
            _dataRepository.Update(industrytypeToUpdate, industrytype);
            return NoContent();
        }
       
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            IndustryType industrytype = _dataRepository.Get(id);
            if (industrytype == null)
            {
                return NotFound("The IndustryType not found.");
            }
            _dataRepository.Delete(industrytype);
            return NoContent();
        }
    }
}
