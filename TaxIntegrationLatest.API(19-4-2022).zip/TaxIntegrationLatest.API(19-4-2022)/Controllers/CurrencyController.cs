﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CurrencyController : ControllerBase
    {
        private readonly IDataRepository<Currency> _dataRepository;
        public CurrencyController(IDataRepository<Currency> dataRepository)
        {
            _dataRepository = dataRepository;
        }
        
        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Currency> currency = _dataRepository.GetAll();
            return Ok(currency);
        }
        
        [HttpGet("{id}", Name = "GetCurrency")]
        public IActionResult Get(long id)
        {
            Currency currency = _dataRepository.Get(id);
            if (currency == null)
            {
                return NotFound("The Currency not found.");
            }
            return Ok(currency);
        }
        
        [HttpPost]
        public IActionResult Post([FromBody] Currency currency)
        {
            if (currency == null)
            {
                return BadRequest("Currency is null.");
            }
            _dataRepository.Add(currency);
            return CreatedAtRoute(
                  "GetCurrency",
                  new { Id = currency.Id },
                  currency);
        }
        
        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Currency currency)
        {
            if (currency == null)
            {
                return BadRequest("Currency is null.");
            }
            Currency currencyToUpdate = _dataRepository.Get(id);
            if (currencyToUpdate == null)
            {
                return NotFound("The Currency not found.");
            }
            _dataRepository.Update(currencyToUpdate, currency);
            return NoContent();
        }
       
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Currency currency = _dataRepository.Get(id);
            if (currency == null)
            {
                return NotFound("The Currency not found.");
            }
            _dataRepository.Delete(currency);
            return NoContent();
        }
    }
}
