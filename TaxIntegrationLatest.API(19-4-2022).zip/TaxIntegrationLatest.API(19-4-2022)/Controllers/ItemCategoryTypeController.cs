﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemCategoryTypeController : ControllerBase
    {
        private readonly IDataRepository<ItemCategoryType> _dataRepository;
        public ItemCategoryTypeController(IDataRepository<ItemCategoryType> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<ItemCategoryType> itemcategorytype = _dataRepository.GetAll();
            return Ok(itemcategorytype);
        }

        [HttpGet("{id}", Name = "GetItemCategoryTypes")]
        public IActionResult Get(long id)
        {
            ItemCategoryType itemcategorytype = _dataRepository.Get(id);
            if (itemcategorytype == null)
            {
                return NotFound("The ItemCategoryType not found.");
            }
            return Ok(itemcategorytype);
        }

        [HttpPost]
        public IActionResult Post([FromBody] ItemCategoryType itemcategorytype)
        {
            if (itemcategorytype == null)
            {
                return BadRequest("ItemCategoryType is null.");
            }
            _dataRepository.Add(itemcategorytype);
            return CreatedAtRoute(
                  "GetItemCategoryTypes",
                  new { Id = itemcategorytype.Id },
                  itemcategorytype);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] ItemCategoryType ItemCategoryType)
        {
            if (ItemCategoryType == null)
            {
                return BadRequest("ItemCategoryType is null.");
            }
            ItemCategoryType ItemCategoryTypeToUpdate = _dataRepository.Get(id);
            if (ItemCategoryTypeToUpdate == null)
            {
                return NotFound("The ItemCategoryType not found.");
            }
            _dataRepository.Update(ItemCategoryTypeToUpdate, ItemCategoryType);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            ItemCategoryType itemcategorytype = _dataRepository.Get(id);
            if (itemcategorytype == null)
            {
                return NotFound("The ItemCategoryType not found.");
            }
            _dataRepository.Delete(itemcategorytype);
            return NoContent();
        }
    }
}
