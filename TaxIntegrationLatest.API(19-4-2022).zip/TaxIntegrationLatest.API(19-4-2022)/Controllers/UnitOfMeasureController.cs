﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UnitOfMeasureController : ControllerBase
    {
        private readonly IDataRepository<UnitOfMeasure> _dataRepository;
        public UnitOfMeasureController(IDataRepository<UnitOfMeasure> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<UnitOfMeasure> unitofmeasure = _dataRepository.GetAll();
            return Ok(unitofmeasure);
        }

        [HttpGet("{id}", Name = "GetUnitOfMeasure")]
        public IActionResult Get(long id)
        {
            UnitOfMeasure unitofmeasure = _dataRepository.Get(id);
            if (unitofmeasure == null)
            {
                return NotFound("The UnitOfMeasure not found.");
            }
            return Ok(unitofmeasure);
        }

        [HttpPost]
        public IActionResult Post([FromBody] UnitOfMeasure unitofmeasure)
        {
            if (unitofmeasure == null)
            {
                return BadRequest("UnitOfMeasure is null.");
            }
            _dataRepository.Add(unitofmeasure);
            return CreatedAtRoute(
                  "GetUnitOfMeasure",
                  new { Id = unitofmeasure.Id },
                  unitofmeasure);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] UnitOfMeasure unitofmeasure)
        {
            if (unitofmeasure == null)
            {
                return BadRequest("UnitOfMeasure is null.");
            }
            UnitOfMeasure UnitOfMeasureToUpdate = _dataRepository.Get(id);
            if (UnitOfMeasureToUpdate == null)
            {
                return NotFound("The UnitOfMeasure not found.");
            }
            _dataRepository.Update(UnitOfMeasureToUpdate, unitofmeasure);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            UnitOfMeasure unitofmeasure = _dataRepository.Get(id);
            if (unitofmeasure == null)
            {
                return NotFound("The UnitOfMeasure not found.");
            }
            _dataRepository.Delete(unitofmeasure);
            return NoContent();
        }
    }
}
