﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OutletController : ControllerBase
    {
        private readonly IDataRepository<Outlet> _dataRepository;
        public OutletController(IDataRepository<Outlet> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Outlet> Outlet = _dataRepository.GetAll();
            return Ok(Outlet);
        }

        [HttpGet("{id}", Name = "GetOutlets")]
        public IActionResult Get(long id)
        {
            Outlet Outlet = _dataRepository.Get(id);
            if (Outlet == null)
            {
                return NotFound("The Outlet not found.");
            }
            return Ok(Outlet);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Outlet Outlet)
        {
            if (Outlet == null)
            {
                return BadRequest("Outlet is null.");
            }
            _dataRepository.Add(Outlet);
            return CreatedAtRoute(
                  "GetOutlets",
                  new { Id = Outlet.ID },
                  Outlet);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Outlet Outlet)
        {
            if (Outlet == null)
            {
                return BadRequest("Outlet is null.");
            }
            Outlet OutletToUpdate = _dataRepository.Get(id);
            if (OutletToUpdate == null)
            {
                return NotFound("The Outlet not found.");
            }
            _dataRepository.Update(OutletToUpdate, Outlet);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Outlet Outlet = _dataRepository.Get(id);
            if (Outlet == null)
            {
                return NotFound("The Outlet not found.");
            }
            _dataRepository.Delete(Outlet);
            return NoContent();
        }
    }
}
