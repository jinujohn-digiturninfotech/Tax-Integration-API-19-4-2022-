﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemCategoryController : ControllerBase
    {
        private readonly IDataRepository<ItemCategory> _dataRepository;
        public ItemCategoryController(IDataRepository<ItemCategory> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<ItemCategory> itemcategory = _dataRepository.GetAll();
            return Ok(itemcategory);
        }

        [HttpGet("{id}", Name = "GetItemCategorys")]
        public IActionResult Get(long id)
        {
            ItemCategory itemcategory = _dataRepository.Get(id);
            if (itemcategory == null)
            {
                return NotFound("The ItemCategory not found.");
            }
            return Ok(itemcategory);
        }

        [HttpPost]
        public IActionResult Post([FromBody] ItemCategory ItemCategory)
        {
            if (ItemCategory == null)
            {
                return BadRequest("ItemCategory is null.");
            }
            _dataRepository.Add(ItemCategory);
            return CreatedAtRoute(
                  "GetItemCategorys",
                  new { Id = ItemCategory.Id },
                  ItemCategory);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] ItemCategory ItemCategory)
        {
            if (ItemCategory == null)
            {
                return BadRequest("ItemCategory is null.");
            }
            ItemCategory ItemCategoryToUpdate = _dataRepository.Get(id);
            if (ItemCategoryToUpdate == null)
            {
                return NotFound("The ItemCategory not found.");
            }
            _dataRepository.Update(ItemCategoryToUpdate, ItemCategory);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            ItemCategory itemcategory = _dataRepository.Get(id);
            if (itemcategory == null)
            {
                return NotFound("The ItemCategory not found.");
            }
            _dataRepository.Delete(itemcategory);
            return NoContent();
        }
    }
}
