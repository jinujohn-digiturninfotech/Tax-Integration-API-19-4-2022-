﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductBatchController : ControllerBase
    {
        private readonly IDataRepository<ProductBatch> _dataRepository;
        public ProductBatchController(IDataRepository<ProductBatch> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<ProductBatch> productbatch = _dataRepository.GetAll();
            return Ok(productbatch);
        }

        [HttpGet("{id}", Name = "GetProductBatchs")]
        public IActionResult Get(long id)
        {
            ProductBatch productbatch = _dataRepository.Get(id);
            if (productbatch == null)
            {
                return NotFound("The ProductBatch not found.");
            }
            return Ok(productbatch);
        }

        [HttpPost]
        public IActionResult Post([FromBody] ProductBatch productbatch)
        {
            if (productbatch == null)
            {
                return BadRequest("ProductBatch is null.");
            }
            _dataRepository.Add(productbatch);
            return CreatedAtRoute(
                  "GetProductBatchs",
                  new { Id = productbatch.Id },
                  productbatch);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] ProductBatch productbatch)
        {
            if (productbatch == null)
            {
                return BadRequest("ProductBatch is null.");
            }
            ProductBatch ProductBatchToUpdate = _dataRepository.Get(id);
            if (ProductBatchToUpdate == null)
            {
                return NotFound("The ProductBatch not found.");
            }
            _dataRepository.Update(ProductBatchToUpdate, productbatch);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            ProductBatch productbatch = _dataRepository.Get(id);
            if (productbatch == null)
            {
                return NotFound("The ProductBatch not found.");
            }
            _dataRepository.Delete(productbatch);
            return NoContent();
        }
    }
}
