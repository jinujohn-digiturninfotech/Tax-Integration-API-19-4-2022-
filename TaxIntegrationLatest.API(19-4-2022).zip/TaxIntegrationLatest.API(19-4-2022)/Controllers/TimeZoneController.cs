﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TimeZoneController : ControllerBase
    {
        private readonly IDataRepository<TimeZoneDetails> _dataRepository;
        public TimeZoneController(IDataRepository<TimeZoneDetails> dataRepository)
        {
            _dataRepository = dataRepository;
        }
        
        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<TimeZoneDetails> timezonedetails = _dataRepository.GetAll();
            return Ok(timezonedetails);
        }
        
        [HttpGet("{id}", Name = "GetTimeZoneDetails")]
        public IActionResult Get(long id)
        {
            TimeZoneDetails timezonedetails = _dataRepository.Get(id);
            if (timezonedetails == null)
            {
                return NotFound("The TimeZone not found.");
            }
            return Ok(timezonedetails);
        }
        
        [HttpPost]
        public IActionResult Post([FromBody] TimeZoneDetails timezonedetails)
        {
            if (timezonedetails == null)
            {
                return BadRequest("TimeZone Details is null.");
            }
            _dataRepository.Add(timezonedetails);
            return CreatedAtRoute(
                  "GetTimeZoneDetails",
                  new { Id = timezonedetails.Id },
                  timezonedetails);
        }
        
        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] TimeZoneDetails timezonedetails)
        {
            if (timezonedetails == null)
            {
                return BadRequest("TimeZone Details is null.");
            }
            TimeZoneDetails TimeZoneToUpdate = _dataRepository.Get(id);
            if (TimeZoneToUpdate == null)
            {
                return NotFound("The TimeZone Details not found.");
            }
            _dataRepository.Update(TimeZoneToUpdate, timezonedetails);
            return NoContent();
        }
       
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            TimeZoneDetails timezonedetails = _dataRepository.Get(id);
            if (timezonedetails == null)
            {
                return NotFound("The TimeZone Details not found.");
            }
            _dataRepository.Delete(timezonedetails);
            return NoContent();
        }
    }
}
