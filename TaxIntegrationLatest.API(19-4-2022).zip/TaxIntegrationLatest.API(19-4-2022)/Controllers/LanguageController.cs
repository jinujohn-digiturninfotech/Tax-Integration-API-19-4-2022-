﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LanguageController : ControllerBase
    {
        private readonly IDataRepository<Language> _dataRepository;
        public LanguageController(IDataRepository<Language> dataRepository)
        {
            _dataRepository = dataRepository;
        }
        
        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Language> language = _dataRepository.GetAll();
            return Ok(language);
        }
        
        [HttpGet("{id}", Name = "GetLanguages")]
        public IActionResult Get(long id)
        {
            Language language = _dataRepository.Get(id);
            if (language == null)
            {
                return NotFound("The Language not found.");
            }
            return Ok(language);
        }
        
        [HttpPost]
        public IActionResult Post([FromBody] Language language)
        {
            if (language == null)
            {
                return BadRequest("Language is null.");
            }
            _dataRepository.Add(language);
            return CreatedAtRoute(
                  "GetLanguages",
                  new { Id = language.Id },
                  language);
        }
        
        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Language language)
        {
            if (language == null)
            {
                return BadRequest("Language is null.");
            }
            Language languageToUpdate = _dataRepository.Get(id);
            if (languageToUpdate == null)
            {
                return NotFound("The Language not found.");
            }
            _dataRepository.Update(languageToUpdate, language);
            return NoContent();
        }
       
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Language language = _dataRepository.Get(id);
            if (language == null)
            {
                return NotFound("The Language not found.");
            }
            _dataRepository.Delete(language);
            return NoContent();
        }
    }
}
