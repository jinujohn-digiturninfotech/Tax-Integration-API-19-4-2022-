﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PositionController : ControllerBase
    {
        private readonly IDataRepository<Position> _dataRepository;
        public PositionController(IDataRepository<Position> dataRepository)
        {
            _dataRepository = dataRepository;
        }
        
        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Position> position = _dataRepository.GetAll();
            return Ok(position);
        }
        
        [HttpGet("{id}", Name = "GetPosition")]
        public IActionResult Get(long id)
        {
            Position position = _dataRepository.Get(id);
            if (position == null)
            {
                return NotFound("The Position not found.");
            }
            return Ok(position);
        }
        
        [HttpPost]
        public IActionResult Post([FromBody] Position position)
        {
            if (position == null)
            {
                return BadRequest("Position is null.");
            }
            _dataRepository.Add(position);
            return CreatedAtRoute(
                  "GetPosition",
                  new { Id = position.Id },
                  position);
        }
        
        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Position position)
        {
            if (position == null)
            {
                return BadRequest("Position is null.");
            }
            Position PositionToUpdate = _dataRepository.Get(id);
            if (PositionToUpdate == null)
            {
                return NotFound("The Position not found.");
            }
            _dataRepository.Update(PositionToUpdate, position);
            return NoContent();
        }
       
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Position position = _dataRepository.Get(id);
            if (position == null)
            {
                return NotFound("The Position not found.");
            }
            _dataRepository.Delete(position);
            return NoContent();
        }
    }
}
