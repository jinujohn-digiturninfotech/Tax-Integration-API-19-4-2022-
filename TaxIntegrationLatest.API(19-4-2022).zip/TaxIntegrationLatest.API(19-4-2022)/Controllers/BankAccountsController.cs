﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;


namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankAccountsController : ControllerBase
    {
        private readonly IDataRepository<BankAccounts> _dataRepository;
        public BankAccountsController(IDataRepository<BankAccounts> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<BankAccounts> bankaccounts = _dataRepository.GetAll();
            return Ok(bankaccounts);
        }

        [HttpGet("{id}", Name = "GetBankAccountss")]
        public IActionResult Get(long id)
        {
            BankAccounts bankaccounts = _dataRepository.Get(id);
            if (bankaccounts == null)
            {
                return NotFound("The BankAccounts not found.");
            }
            return Ok(bankaccounts);
        }

        [HttpPost]
        public IActionResult Post([FromBody] BankAccounts bankaccounts)
        {
            if (bankaccounts == null)
            {
                return BadRequest("BankAccounts is null.");
            }
            _dataRepository.Add(bankaccounts);
            return CreatedAtRoute(
                  "GetBankAccountss",
                  new { Id = bankaccounts.Id },
                  bankaccounts);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] BankAccounts bankaccounts)
        {
            if (bankaccounts == null)
            {
                return BadRequest("BankAccounts is null.");
            }
            BankAccounts BankAccountsToUpdate = _dataRepository.Get(id);
            if (BankAccountsToUpdate == null)
            {
                return NotFound("The BankAccounts not found.");
            }
            _dataRepository.Update(BankAccountsToUpdate, bankaccounts);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            BankAccounts bankaccounts = _dataRepository.Get(id);
            if (bankaccounts == null)
            {
                return NotFound("The BankAccounts not found.");
            }
            _dataRepository.Delete(bankaccounts);
            return NoContent();
        }
    }
}
