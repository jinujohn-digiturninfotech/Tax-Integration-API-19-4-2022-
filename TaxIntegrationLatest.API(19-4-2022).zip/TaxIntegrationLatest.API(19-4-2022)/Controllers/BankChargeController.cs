﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankChargeController : ControllerBase
    {
        private readonly IDataRepository<BankCharge> _dataRepository;
        public BankChargeController(IDataRepository<BankCharge> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<BankCharge> BankCharge = _dataRepository.GetAll();
            return Ok(BankCharge);
        }

        [HttpGet("{id}", Name = "GetBankCharges")]
        public IActionResult Get(long id)
        {
            BankCharge BankCharge = _dataRepository.Get(id);
            if (BankCharge == null)
            {
                return NotFound("The BankCharge not found.");
            }
            return Ok(BankCharge);
        }

        [HttpPost]
        public IActionResult Post([FromBody] BankCharge BankCharge)
        {
            if (BankCharge == null)
            {
                return BadRequest("BankCharge is null.");
            }
            _dataRepository.Add(BankCharge);
            return CreatedAtRoute(
                  "Get",
                  new { Id = BankCharge.ID },
                  BankCharge);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] BankCharge BankCharge)
        {
            if (BankCharge == null)
            {
                return BadRequest("BankCharge is null.");
            }
            BankCharge BankChargeToUpdate = _dataRepository.Get(id);
            if (BankChargeToUpdate == null)
            {
                return NotFound("The BankCharge not found.");
            }
            _dataRepository.Update(BankChargeToUpdate, BankCharge);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            BankCharge BankCharge = _dataRepository.Get(id);
            if (BankCharge == null)
            {
                return NotFound("The BankCharge not found.");
            }
            _dataRepository.Delete(BankCharge);
            return NoContent();
        }

    }
}
