﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SocialNetworkController : ControllerBase
    {
        private readonly IDataRepository<SocialNetwork> _dataRepository;
        public SocialNetworkController(IDataRepository<SocialNetwork> dataRepository)
        {
            _dataRepository = dataRepository;
        }
        
        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<SocialNetwork> socialnetwork = _dataRepository.GetAll();
            return Ok(socialnetwork);
        }
        
        [HttpGet("{id}", Name = "GetSocialNetwork")]
        public IActionResult Get(long id)
        {
            SocialNetwork socialnetwork = _dataRepository.Get(id);
            if (socialnetwork == null)
            {
                return NotFound("The Location not found.");
            }
            return Ok(socialnetwork);
        }
        
        [HttpPost]
        public IActionResult Post([FromBody] SocialNetwork socialnetwork)
        {
            if (socialnetwork == null)
            {
                return BadRequest("Location is null.");
            }
            _dataRepository.Add(socialnetwork);
            return CreatedAtRoute(
                  "GetSocialNetwork",
                  new { Id = socialnetwork.Id },
                  socialnetwork);
        }
        
        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] SocialNetwork socialnetwork)
        {
            if (socialnetwork == null)
            {
                return BadRequest("socialnetwork is null.");
            }
            SocialNetwork socialnetworkToUpdate = _dataRepository.Get(id);
            if (socialnetworkToUpdate == null)
            {
                return NotFound("The socialnetwork not found.");
            }
            _dataRepository.Update(socialnetworkToUpdate, socialnetwork);
            return NoContent();
        }
       
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            SocialNetwork socialnetwork = _dataRepository.Get(id);
            if (socialnetwork == null)
            {
                return NotFound("The socialnetwork not found.");
            }
            _dataRepository.Delete(socialnetwork);
            return NoContent();
        }
    }
}
