﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EntityController : ControllerBase
    {
        private readonly IDataRepository<Entity> _dataRepository;
        public EntityController(IDataRepository<Entity> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Entity> Entity = _dataRepository.GetAll();
            return Ok(Entity);
        }

        [HttpGet("{id}", Name = "GetEntitys")]
        public IActionResult Get(long id)
        {
            Entity Entity = _dataRepository.Get(id);
            if (Entity == null)
            {
                return NotFound("The Entity not found.");
            }
            return Ok(Entity);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Entity Entity)
        {
            if (Entity == null)
            {
                return BadRequest("Entity is null.");
            }
            _dataRepository.Add(Entity);
            return CreatedAtRoute(
                  "GetEntitys",
                  new { Id = Entity.Id },
                  Entity);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Entity Entity)
        {
            if (Entity == null)
            {
                return BadRequest("Entity is null.");
            }
            Entity EntityToUpdate = _dataRepository.Get(id);
            if (EntityToUpdate == null)
            {
                return NotFound("The Entity not found.");
            }
            _dataRepository.Update(EntityToUpdate, Entity);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Entity Entity = _dataRepository.Get(id);
            if (Entity == null)
            {
                return NotFound("The Entity not found.");
            }
            _dataRepository.Delete(Entity);
            return NoContent();
        }
    }
}
