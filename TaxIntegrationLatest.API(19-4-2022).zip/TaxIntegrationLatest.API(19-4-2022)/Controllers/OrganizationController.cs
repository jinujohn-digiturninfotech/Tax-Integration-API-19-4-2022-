﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrganizationController : ControllerBase
    {

        private readonly IDataRepository<Organization> _dataRepository;
        public OrganizationController(IDataRepository<Organization> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Organization> Organization = _dataRepository.GetAll();
            return Ok(Organization);
        }

        [HttpGet("{id}", Name = "GetOrganizations")]
        public IActionResult Get(long id)
        {
            Organization Organization = _dataRepository.Get(id);
            if (Organization == null)
            {
                return NotFound("The Organization not found.");
            }
            return Ok(Organization);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Organization Organization)
        {
            if (Organization == null)
            {
                return BadRequest("Organization is null.");
            }
            _dataRepository.Add(Organization);
            return CreatedAtRoute(
                  "GetOrganizations",
                  new { Id = Organization.Id },
                  Organization);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Organization Organization)
        {
            if (Organization == null)
            {
                return BadRequest("Organization is null.");
            }
            Organization OrganizationToUpdate = _dataRepository.Get(id);
            if (OrganizationToUpdate == null)
            {
                return NotFound("The Organization not found.");
            }
            _dataRepository.Update(OrganizationToUpdate, Organization);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Organization Organization = _dataRepository.Get(id);
            if (Organization == null)
            {
                return NotFound("The Organization not found.");
            }
            _dataRepository.Delete(Organization);
            return NoContent();
        }
    }
}
