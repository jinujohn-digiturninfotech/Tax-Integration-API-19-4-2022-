﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentMethodController : ControllerBase
    {
        private readonly IDataRepository<PaymentMethod> _dataRepository;
        public PaymentMethodController(IDataRepository<PaymentMethod> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<PaymentMethod> PaymentMethod = _dataRepository.GetAll();
            return Ok(PaymentMethod);
        }

        [HttpGet("{id}", Name = "GetPaymentMethods")]
        public IActionResult Get(long id)
        {
            PaymentMethod PaymentMethod = _dataRepository.Get(id);
            if (PaymentMethod == null)
            {
                return NotFound("The PaymentMethod not found.");
            }
            return Ok(PaymentMethod);
        }

        [HttpPost]
        public IActionResult Post([FromBody] PaymentMethod PaymentMethod)
        {
            if (PaymentMethod == null)
            {
                return BadRequest("PaymentMethod is null.");
            }
            _dataRepository.Add(PaymentMethod);
            return CreatedAtRoute(
                  "GetPaymentMethods",
                  new { Id = PaymentMethod.Id },
                  PaymentMethod);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] PaymentMethod PaymentMethod)
        {
            if (PaymentMethod == null)
            {
                return BadRequest("PaymentMethod is null.");
            }
            PaymentMethod PaymentMethodToUpdate = _dataRepository.Get(id);
            if (PaymentMethodToUpdate == null)
            {
                return NotFound("The PaymentMethod not found.");
            }
            _dataRepository.Update(PaymentMethodToUpdate, PaymentMethod);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            PaymentMethod PaymentMethod = _dataRepository.Get(id);
            if (PaymentMethod == null)
            {
                return NotFound("The PaymentMethod not found.");
            }
            _dataRepository.Delete(PaymentMethod);
            return NoContent();
        }
    }
}
