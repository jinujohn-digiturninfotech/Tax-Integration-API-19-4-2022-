﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly IDataRepository<Department> _dataRepository;
        public DepartmentController(IDataRepository<Department> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Department> department = _dataRepository.GetAll();
            return Ok(department);
        }

        [HttpGet("{id}", Name = "GetDepartments")]
        public IActionResult Get(long id)
        {
            Department department = _dataRepository.Get(id);
            if (department == null)
            {
                return NotFound("The Department not found.");
            }
            return Ok(department);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Department department)
        {
            if (department == null)
            {
                return BadRequest("Department is null.");
            }
            _dataRepository.Add(department);
            return CreatedAtRoute(
                  "GetDepartments",
                  new { Id = department.Id },
                  department);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Department department)
        {
            if (department == null)
            {
                return BadRequest("Department is null.");
            }
            Department DepartmentToUpdate = _dataRepository.Get(id);
            if (DepartmentToUpdate == null)
            {
                return NotFound("The Department not found.");
            }
            _dataRepository.Update(DepartmentToUpdate, department);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Department department = _dataRepository.Get(id);
            if (department == null)
            {
                return NotFound("The Department not found.");
            }
            _dataRepository.Delete(department);
            return NoContent();
        }
    }
}
