﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaxCategoryController : ControllerBase
    {
        private readonly IDataRepository<TaxCategory> _dataRepository;
        public TaxCategoryController(IDataRepository<TaxCategory> dataRepository)
        {
            _dataRepository = dataRepository;
        }
        
        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<TaxCategory> taxcategory = _dataRepository.GetAll();
            return Ok(taxcategory);
        }
        
        [HttpGet("{id}", Name = "GetTaxCategory")]
        public IActionResult Get(long id)
        {
            TaxCategory taxcategory = _dataRepository.Get(id);
            if (taxcategory == null)
            {
                return NotFound("The Tax Category not found.");
            }
            return Ok(taxcategory);
        }
        
        [HttpPost]
        public IActionResult Post([FromBody] TaxCategory taxcategory)
        {
            if (taxcategory == null)
            {
                return BadRequest("TaxCategory is null.");
            }
            _dataRepository.Add(taxcategory);
            return CreatedAtRoute(
                  "GetTaxCategory",
                  new { Id = taxcategory.Id },
                  taxcategory);
        }
        
        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] TaxCategory taxcategory)
        {
            if (taxcategory == null)
            {
                return BadRequest("TaxCategory is null.");
            }
            TaxCategory taxcategoryToUpdate = _dataRepository.Get(id);
            if (taxcategoryToUpdate == null)
            {
                return NotFound("The TaxCategory not found.");
            }
            _dataRepository.Update(taxcategoryToUpdate, taxcategory);
            return NoContent();
        }
       
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            TaxCategory taxcategory = _dataRepository.Get(id);
            if (taxcategory == null)
            {
                return NotFound("The TaxCategory not found.");
            }
            _dataRepository.Delete(taxcategory);
            return NoContent();
        }
    }
}
