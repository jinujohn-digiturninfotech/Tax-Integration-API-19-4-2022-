﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;


namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalesController : ControllerBase
    {
        private readonly IDataRepository<Sales> _dataRepository;
        public SalesController(IDataRepository<Sales> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Sales> sales = _dataRepository.GetAll();
            return Ok(sales);
        }

        [HttpGet("{id}", Name = "GetSaless")]
        public IActionResult Get(long id)
        {
            Sales sales = _dataRepository.Get(id);
            if (sales == null)
            {
                return NotFound("The Sales not found.");
            }
            return Ok(sales);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Sales sales)
        {
            if (sales == null)
            {
                return BadRequest("Sales is null.");
            }
            _dataRepository.Add(sales);
            return CreatedAtRoute(
                  "GetSaless",
                  new { Id = sales.Id },
                  sales);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Sales sales)
        {
            if (sales == null)
            {
                return BadRequest("Sales is null.");
            }
            Sales SalesToUpdate = _dataRepository.Get(id);
            if (SalesToUpdate == null)
            {
                return NotFound("The Sales not found.");
            }
            _dataRepository.Update(SalesToUpdate, sales);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Sales sales = _dataRepository.Get(id);
            if (sales == null)
            {
                return NotFound("The Sales not found.");
            }
            _dataRepository.Delete(sales);
            return NoContent();
        }
    }
}
