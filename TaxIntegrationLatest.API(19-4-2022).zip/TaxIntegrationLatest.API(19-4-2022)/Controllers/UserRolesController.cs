﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserRolesController : ControllerBase
    {
        private readonly IDataRepository<UserRoles> _dataRepository;
        public UserRolesController(IDataRepository<UserRoles> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<UserRoles> userroles = _dataRepository.GetAll();
            return Ok(userroles);
        }

        [HttpGet("{id}", Name = "GetUserRoless")]
        public IActionResult Get(long id)
        {
            UserRoles userroles = _dataRepository.Get(id);
            if (userroles == null)
            {
                return NotFound("The UserRoles not found.");
            }
            return Ok(userroles);
        }

        [HttpPost]
        public IActionResult Post([FromBody] UserRoles userroles)
        {
            if (userroles == null)
            {
                return BadRequest("UserRoles is null.");
            }
            _dataRepository.Add(userroles);
            return CreatedAtRoute(
                  "GetUserRoless",
                  new { Id = userroles.Id },
                  userroles);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] UserRoles userroles)
        {
            if (userroles == null)
            {
                return BadRequest("UserRoles is null.");
            }
            UserRoles UserRolesToUpdate = _dataRepository.Get(id);
            if (UserRolesToUpdate == null)
            {
                return NotFound("The UserRoles not found.");
            }
            _dataRepository.Update(UserRolesToUpdate, userroles);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            UserRoles userroles = _dataRepository.Get(id);
            if (userroles == null)
            {
                return NotFound("The UserRoles not found.");
            }
            _dataRepository.Delete(userroles);
            return NoContent();
        }
    }
}
