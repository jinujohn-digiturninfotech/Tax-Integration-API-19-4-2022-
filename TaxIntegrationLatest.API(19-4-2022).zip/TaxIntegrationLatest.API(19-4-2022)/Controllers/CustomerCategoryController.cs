﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerCategoryController : ControllerBase
    {
        private readonly IDataRepository<CustomerCategory> _dataRepository;
        public CustomerCategoryController(IDataRepository<CustomerCategory> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<CustomerCategory> customercategory = _dataRepository.GetAll();
            return Ok(customercategory);
        }

        [HttpGet("{id}", Name = "GetCustomerCategorys")]
        public IActionResult Get(long id)
        {
            CustomerCategory customercategory = _dataRepository.Get(id);
            if (customercategory == null)
            {
                return NotFound("The CustomerCategory not found.");
            }
            return Ok(customercategory);
        }

        [HttpPost]
        public IActionResult Post([FromBody] CustomerCategory customercategory)
        {
            if (customercategory == null)
            {
                return BadRequest("CustomerCategory is null.");
            }
            _dataRepository.Add(customercategory);
            return CreatedAtRoute(
                  "GetCustomerCategorys",
                  new { Id = customercategory.Id },
                  customercategory);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] CustomerCategory customercategory)
        {
            if (customercategory == null)
            {
                return BadRequest("CustomerCategory is null.");
            }
            CustomerCategory CustomerCategoryToUpdate = _dataRepository.Get(id);
            if (CustomerCategoryToUpdate == null)
            {
                return NotFound("The CustomerCategory not found.");
            }
            _dataRepository.Update(CustomerCategoryToUpdate, customercategory);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            CustomerCategory customercategory = _dataRepository.Get(id);
            if (customercategory == null)
            {
                return NotFound("The CustomerCategory not found.");
            }
            _dataRepository.Delete(customercategory);
            return NoContent();
        }
    }
}
