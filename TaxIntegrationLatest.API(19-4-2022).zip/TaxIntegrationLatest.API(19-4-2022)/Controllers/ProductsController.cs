﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IDataRepository<Products> _dataRepository;
        public ProductsController(IDataRepository<Products> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Products> products = _dataRepository.GetAll();
            return Ok(products);
        }

        [HttpGet("{id}", Name = "GetProductss")]
        public IActionResult Get(long id)
        {
            Products products = _dataRepository.Get(id);
            if (products == null)
            {
                return NotFound("The Products not found.");
            }
            return Ok(products);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Products products)
        {
            if (products == null)
            {
                return BadRequest("Products is null.");
            }
            _dataRepository.Add(products);
            return CreatedAtRoute(
                  "GetProductss",
                  new { Id = products.Id },
                  products);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Products products)
        {
            if (products == null)
            {
                return BadRequest("Products is null.");
            }
            Products ProductsToUpdate = _dataRepository.Get(id);
            if (ProductsToUpdate == null)
            {
                return NotFound("The Products not found.");
            }
            _dataRepository.Update(ProductsToUpdate, products);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Products products = _dataRepository.Get(id);
            if (products == null)
            {
                return NotFound("The Products not found.");
            }
            _dataRepository.Delete(products);
            return NoContent();
        }
    }
}
