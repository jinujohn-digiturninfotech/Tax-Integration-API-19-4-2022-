﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddressController : ControllerBase
    {
        private readonly IDataRepository<Address> _dataRepository;
        public AddressController(IDataRepository<Address> dataRepository)
        {
            _dataRepository = dataRepository;
        }
        
        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Address> address = _dataRepository.GetAll();
            return Ok(address);
        }
        
        [HttpGet("{id}", Name = "GetAddress")]
        public IActionResult Get(long id)
        {
            Address address = _dataRepository.Get(id);
            if (address == null)
            {
                return NotFound("The Address not found.");
            }
            return Ok(address);
        }
        
        [HttpPost]
        public IActionResult Post([FromBody] Address address)
        {
            if (address == null)
            {
                return BadRequest("Address is null.");
            }
            _dataRepository.Add(address);
            return CreatedAtRoute(
                  "GetAddress",
                  new { Id = address.Id },
                  address);
        }
        
        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Address address)
        {
            if (address == null)
            {
                return BadRequest("Address is null.");
            }
            Address AddressToUpdate = _dataRepository.Get(id);
            if (AddressToUpdate == null)
            {
                return NotFound("The Address not found.");
            }
            _dataRepository.Update(AddressToUpdate, address);
            return NoContent();
        }
       
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Address address = _dataRepository.Get(id);
            if (address == null)
            {
                return NotFound("The Address not found.");
            }
            _dataRepository.Delete(address);
            return NoContent();
        }
    }
}
