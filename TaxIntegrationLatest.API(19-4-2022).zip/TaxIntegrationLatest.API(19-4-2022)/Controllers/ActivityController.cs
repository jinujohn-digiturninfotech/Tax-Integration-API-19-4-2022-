﻿
using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;


namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActivityController : ControllerBase
    {
        private readonly IDataRepository<Activity> _dataRepository;
        public ActivityController(IDataRepository<Activity> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<Activity> activity = _dataRepository.GetAll();
            return Ok(activity);
        }

        [HttpGet("{id}", Name = "GetActivitys")]
        public IActionResult Get(long id)
        {
            Activity activity = _dataRepository.Get(id);
            if (activity == null)
            {
                return NotFound("The Activity not found.");
            }
            return Ok(activity);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Activity activity)
        {
            if (activity == null)
            {
                return BadRequest("Activity is null.");
            }
            _dataRepository.Add(activity);
            return CreatedAtRoute(
                  "GetActivitys",
                  new { Id = activity.Id },
                  activity);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] Activity activity)
        {
            if (activity == null)
            {
                return BadRequest("Activity is null.");
            }
            Activity ActivityToUpdate = _dataRepository.Get(id);
            if (ActivityToUpdate == null)
            {
                return NotFound("The Activity not found.");
            }
            _dataRepository.Update(ActivityToUpdate, activity);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            Activity activity = _dataRepository.Get(id);
            if (activity == null)
            {
                return NotFound("The Activity not found.");
            }
            _dataRepository.Delete(activity);
            return NoContent();
        }
    }
}
