﻿using Microsoft.AspNetCore.Mvc;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IDataRepository<User> _dataRepository;
        public UserController(IDataRepository<User> dataRepository)
        {
            _dataRepository = dataRepository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            IEnumerable<User> user = _dataRepository.GetAll();
            return Ok(user);
        }

        [HttpGet("{id}", Name = "GetUsers")]
        public IActionResult Get(long id)
        {
            User user = _dataRepository.Get(id);
            if (user == null)
            {
                return NotFound("The User not found.");
            }
            return Ok(user);
        }

        [HttpPost]
        public IActionResult Post([FromBody] User user)
        {
            if (user == null)
            {
                return BadRequest("User is null.");
            }
            _dataRepository.Add(user);
            return CreatedAtRoute(
                  "GetUsers",
                  new { Id = user.Id },
                  user);
        }

        [HttpPut("{id}")]
        public IActionResult Put(long id, [FromBody] User user)
        {
            if (user == null)
            {
                return BadRequest("User is null.");
            }
            User UserToUpdate = _dataRepository.Get(id);
            if (UserToUpdate == null)
            {
                return NotFound("The User not found.");
            }
            _dataRepository.Update(UserToUpdate, user);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            User user = _dataRepository.Get(id);
            if (user == null)
            {
                return NotFound("The User not found.");
            }
            _dataRepository.Delete(user);
            return NoContent();
        }
    }
}
