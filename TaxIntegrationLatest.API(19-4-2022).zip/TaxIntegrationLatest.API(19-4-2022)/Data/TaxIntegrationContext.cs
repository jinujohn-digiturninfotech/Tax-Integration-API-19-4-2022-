﻿using Microsoft.EntityFrameworkCore;
using TaxIntegrationLatest.API.Models;
using TimeZone = TaxIntegrationLatest.API.Models.TimeZoneDetails;

namespace TaxIntegrationLatest.API.Data
{
    public class TaxIntegrationContext : DbContext
    {


        public TaxIntegrationContext(DbContextOptions<TaxIntegrationContext> options) : base(options)
        {

        }
        // set unique key
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Language>()
                .HasIndex(u => u.LanguageName)
                .IsUnique();

            builder.Entity<PaymentMethod>()
               .HasIndex(u => u.Code)
               .IsUnique();

        builder.Entity<Address>()//first table(FK Base Table)
       .HasOne<Employee>(e => e.employee)//first table(FK implemented table)
       .WithOne(em => em.Address)//second table
       .HasForeignKey<Employee>(em => em.AddressID);//second table - foreign key

            builder.Entity<Department>()
                    .HasOne<Employee>(e => e.employee)
                    .WithOne(em => em.Department)
                    .HasForeignKey<Employee>(em => em.DepartmentID);
           
            builder.Entity<Position>()
                    .HasOne<Employee>(e => e.employee)
                    .WithOne(em => em.Position)
                     .HasForeignKey<Employee>(em => em.PositionID);


            //builder.Entity<Employee>()
            //         .HasOne(e => e.Reporting)
            //         .WithMany()
            //         .HasForeignKey(e => e.ReportingManagerID);


            //// own table(pk) set fk as same table
            //builder.Entity<Employee>()
            //    .HasOne<Employee>(e => e.employee)
            //    .WithOne(em => em.employee)
            //    .HasForeignKey<Employee>(em => em.ReportingManagerID);

            builder.Entity<Activity>()
                   .HasOne<Employee>(e => e.employee)
                   .WithOne(em => em.Activity)
                   .HasForeignKey<Employee>(em => em.ActivityID);

            builder.Entity<Organization>()
                   .HasOne<Employee>(e => e.employee)
                   .WithOne(em => em.Organization)
                   .HasForeignKey<Employee>(em => em.OrganizationID);

            builder.Entity<Currency>()
                   .HasOne<Employee>(e => e.employee)
                   .WithOne(em => em.Currency)
                   .HasForeignKey<Employee>(em => em.CurrencyID);

            builder.Entity<IndustryType>()
                    .HasOne<Organization>(o => o.organization)
                    .WithOne(or => or.IndustryType)
                    .HasForeignKey<Organization>(or => or.IndustryTypeID);

            builder.Entity<Language>()
                   .HasOne<Organization>(o => o.organization)
                   .WithOne(or => or.Language)
                   .HasForeignKey<Organization>(or => or.DefaultLanguageID);

            builder.Entity<Address>()
                   .HasOne<Organization>(o => o.organization)
                   .WithOne(or => or.Address)
                   .HasForeignKey<Organization>(or => or.AddressID);

            builder.Entity<Location>()
                  .HasOne<Organization>(o => o.organization)
                  .WithOne(or => or.Location)
                  .HasForeignKey<Organization>(or => or.BusinessLocationID);

            builder.Entity<SocialNetwork>()
                  .HasOne<Organization>(o => o.organization)
                  .WithOne(or => or.SocialNetwork)
                  .HasForeignKey<Organization>(or => or.SocialNetworkID);
        }

       
        public DbSet<Language> Languages { get; set; }
        public DbSet<Location> Locations { get; set; }
        public DbSet<SocialNetwork> SocialNetworks { get; set; }
        public DbSet<IndustryType> IndustryTypes { get; set; }
        public DbSet<TaxCategory> TaxCategories { get; set; }
        public DbSet<Currency> Currencies { get; set; }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<TimeZoneDetails> TimeZones { get; set; }
        public DbSet<Position> Positions { get; set; }
        public DbSet<Activity> Activities { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<CustomerCategory> CustomerCategories { get; set; }
        public DbSet<Customers> Customerss { get; set; }
        public DbSet<ItemCategoryType> ItemCategoryTypes { get; set; }
        public DbSet<UnitOfMeasure> UnitOfMeasures { get; set; }
        public DbSet<UserRoles> UserRoless { get; set; }
        public DbSet<BankAccounts> BankAccountss { get; set; }
        public DbSet<ItemCategory> ItemCategories { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<ProductBatch> ProductBatches { get; set; }
        public DbSet<Products> Productss { get; set; }
        public DbSet<Sales> Saless { get; set; }
        public DbSet<Employee> Employees { get; set; }

        public DbSet<PaymentMethod> PaymentMethods { get; set; }
        public DbSet<BankCharge> BankCharges { get; set; }
        public DbSet<Outlet> Outlets { get; set; }

        public DbSet<Entity> Entities { get; set; }

        public DbSet<Organization> Organizations { get; set; }
    }
}
