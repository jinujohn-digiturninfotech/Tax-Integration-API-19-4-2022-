global using Microsoft.EntityFrameworkCore;
using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models;
using TaxIntegrationLatest.API.Models.DataManager;
using TaxIntegrationLatest.API.Models.Repository;

var builder = WebApplication.CreateBuilder(args);



// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddDbContext<TaxIntegrationContext>(options => {
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnectionString"));
});
builder.Services.AddScoped<IDataRepository<Language>, LanguageManager>();
builder.Services.AddScoped<IDataRepository<BankCharge>, BankChargeManager>();
builder.Services.AddScoped<IDataRepository<Location>, LocationManager>();
builder.Services.AddScoped<IDataRepository<SocialNetwork>, SocialNetworkManager>();
builder.Services.AddScoped<IDataRepository<IndustryType>, IndustryTypeManager>();
builder.Services.AddScoped<IDataRepository<TaxCategory>, TaxCategoryManager>();
builder.Services.AddScoped<IDataRepository<Currency>, CurrencyManager>();
builder.Services.AddScoped<IDataRepository<Address>, AddressManager>();
builder.Services.AddScoped<IDataRepository<TimeZoneDetails>, TimeZoneManager >();
builder.Services.AddScoped<IDataRepository<Position>, PositionManager>();
builder.Services.AddScoped<IDataRepository<Activity>, ActivityManager>();
builder.Services.AddScoped<IDataRepository<Department>, DepartmentManager>();
builder.Services.AddScoped<IDataRepository<CustomerCategory>, CustomerCategoryManager>();
builder.Services.AddScoped<IDataRepository<ItemCategoryType>, ItemCategoryTypeManager>();
builder.Services.AddScoped<IDataRepository<UnitOfMeasure>, UnitOfMeasureManager>();
builder.Services.AddScoped<IDataRepository<UserRoles>, UserRolesManager>();
builder.Services.AddScoped<IDataRepository<BankAccounts>, BankAccountsManager>();
builder.Services.AddScoped<IDataRepository<ItemCategory>, ItemCategoryManager>();
builder.Services.AddScoped<IDataRepository<User>, UserManager>();
builder.Services.AddScoped<IDataRepository<ProductBatch>, ProductBatchManager>();
builder.Services.AddScoped<IDataRepository<Products>, ProductsManager>();
builder.Services.AddScoped<IDataRepository<Sales>, SalesManager>();
builder.Services.AddScoped<IDataRepository<Customers>, CustomersManager>();
builder.Services.AddScoped<IDataRepository<Employee>, EmployeeManager>();
builder.Services.AddScoped<IDataRepository<PaymentMethod>, PaymentMethodManager>();
builder.Services.AddScoped<IDataRepository<Outlet>, OutletManager>();
builder.Services.AddScoped<IDataRepository<Entity>, EntityManager>();
builder.Services.AddScoped<IDataRepository<Organization>, OrganizationManager>();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
