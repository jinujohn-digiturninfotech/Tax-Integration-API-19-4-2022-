﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models
{
    public class Department
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter Activity Name")]
        [Column(TypeName = "nvarchar(100)")]
        public string? DepartmentName { get; set; }

       // [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
       // [JsonIgnore]
       // public virtual Organization? Organization { get; set; }
       public virtual Employee? employee { get; set; }
    }
}

