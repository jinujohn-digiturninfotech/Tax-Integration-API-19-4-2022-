﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class Outlet
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int ID { get; set; }

        [Required(ErrorMessage = "Please Enter Outlet Name")]
        [Column(TypeName = "nvarchar(100)")]
        public string? OutletName { get; set; }

       // [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OutletSequence { get; set; }

       // [ForeignKey("Entity")]
        public int EntityID { get; set; }

      //  [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
        //[JsonIgnore]
        //public virtual Organization? Organization { get; set; }
       // public virtual Entity? Entity { get; set; }
       // public virtual Outlet? Entity1 { get; set; }

    }
}
