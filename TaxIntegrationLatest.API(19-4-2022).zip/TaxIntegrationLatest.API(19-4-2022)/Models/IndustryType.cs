﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models
{
    public class IndustryType
    {


        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please select Industry Type Name")]
        [Column(TypeName = "nvarchar(100)")]
        public string? IndustryTypeDesc { get; set; }
        public Boolean IsActive { get; set; }
        //[JsonIgnore]
        //public virtual IndustryType? Organization { get; set; }
        public virtual Organization? organization { get; set; }
    }
}
