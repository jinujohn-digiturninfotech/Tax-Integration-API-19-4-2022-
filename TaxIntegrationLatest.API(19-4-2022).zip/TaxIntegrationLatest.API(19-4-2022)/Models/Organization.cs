﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class Organization
    {



        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]

       
        public int Id { get; set; }

       // [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OrganizationSequence { get; set; }

        [Required(ErrorMessage = "Please Enter Organization Name")]
        [Column(TypeName = "nvarchar(200)")]
        public string? OrganizationName { get; set; }

        [Required(ErrorMessage = "Please Enter Organization Local Name")]
        [Column(TypeName = "nvarchar(200)")]
        public string? OrganizationNameLocal { get; set; }


        [ForeignKey("IndustryType")]
        public int IndustryTypeID { get; set; }
        public virtual IndustryType? IndustryType { get; set; }

        [ForeignKey("Location")]
        public int BusinessLocationID { get; set; }
        public virtual Location? Location { get; set; }
        [ForeignKey("Address")]
        public int AddressID { get; set; }
        public virtual Address? Address { get; set; }

        [ForeignKey("SocialNetwork")]
        public int SocialNetworkID { get; set; }
        public virtual SocialNetwork? SocialNetwork { get; set; }
        [Required(ErrorMessage = "Please Enter TRN_VAT_NO")]
        [Column(TypeName = "nvarchar(20)")]
        public string? TRN_VAT_NO { get; set; }


        [Required(ErrorMessage = "Please Enter TRN_Registration_Name")]
        [Column(TypeName = "nvarchar(200)")]
        public string? TRN_Registration_Name { get; set; }

        [Required(ErrorMessage = "Please Enter CR Number")]
        [Column(TypeName = "nvarchar(25)")]
        public string? CR_Number { get; set; }

        [ForeignKey("Currency")]
        public int CurrencyID { get; set; }
        public virtual Currency? Currency { get; set; }
        [ForeignKey("Language")]
        public int DefaultLanguageID { get; set; }
        public virtual Language? Language { get; set; }
        [Required(ErrorMessage = "Please Enter Timezone")]
        [Column(TypeName = "nvarchar(200)")]
        public string? Timezone { get; set; }

        [Required(ErrorMessage = "Please Enter Date Format")]
        [Column(TypeName = "nvarchar(30)")]
        public string? DateFormat { get; set; }

        public Boolean EntitiesAvailable { get; set; }
        public Boolean IsActive { get; set; }

        //foreign key
        // [JsonIgnore]
        // public virtual Organization? Employee { get; set; }
        // public virtual Organization? Entities { get; set; }
        // public virtual Organization? PaymentMethod { get; set; }
        // public virtual Organization? Language { get; set; }
        //[JsonIgnore]
        //public virtual IndustryType? IndustryType { get; set; }
        //[JsonIgnore]
        //public virtual Location? Location { get; set; }
        //[JsonIgnore]
        //public virtual Address? address { get; set; }
        //[JsonIgnore]
        //public virtual SocialNetwork? SocialNetwork { get; set; }
        //[JsonIgnore]
        //public virtual Currency? Currency { get; set; }
        //[JsonIgnore]

        //public virtual Language? Language { get; set; }
        public virtual Employee? employee { get; set; }

    }
}
