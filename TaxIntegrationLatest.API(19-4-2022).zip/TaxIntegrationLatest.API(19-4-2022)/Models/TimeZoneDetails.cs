﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models
{
    public class TimeZoneDetails
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

       // [Required(ErrorMessage = "Please Select TimeZone ")]
        [Column(TypeName = "nvarchar(100)")]
        public string? ZoneName { get; set; }

      //  [Required]
        [Column(TypeName = "nvarchar(10)")]
        public string ZoneAbbreviation { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal UTCDifference { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string? DisplayName { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime UpdatedOn { get; set; }

        public int UpdatedBy { get; set; }
        public Boolean IsActive { get; set; }
    }
}
