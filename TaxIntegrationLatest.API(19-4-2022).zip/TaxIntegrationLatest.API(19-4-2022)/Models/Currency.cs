﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models
{
    public class Currency
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter Currency Name")]
        [Column(TypeName = "nvarchar(50)")]
        public string? CurrencyName { get; set; }
        public Boolean IsActive { get; set; }
       // [JsonIgnore]
       // public virtual Currency? Organization { get; set; }
        public virtual Employee? employee { get; set; }
        //public virtual Organization? organization { get; set; }
    }
}
