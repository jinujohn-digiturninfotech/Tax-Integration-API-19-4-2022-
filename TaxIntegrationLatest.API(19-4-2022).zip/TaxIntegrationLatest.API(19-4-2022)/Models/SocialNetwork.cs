﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models
{
    public class SocialNetwork
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Column(TypeName = "nvarchar(200)")]
        public string? FacebookPage { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string? TwitterHandle { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string? InstaPage { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string? Website { get; set; }
        public Boolean IsActive { get; set; }
        //[JsonIgnore]
        //public virtual SocialNetwork? Organization { get; set; }
        public virtual Organization? organization { get; set; }

    }
}
