﻿using System.Collections.Generic;
using System.Linq;
using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class IndustryTypeManager: IDataRepository<IndustryType>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public IndustryTypeManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<IndustryType> GetAll()
        {
            return _TaxIntegrationContext.IndustryTypes.Where(x => x.IsActive).ToList();
        }
        public IndustryType Get(long id)
        {
            return _TaxIntegrationContext.IndustryTypes.FirstOrDefault(e => e.Id == id);
        }
        public void Add(IndustryType entity)
        {
            _TaxIntegrationContext.IndustryTypes.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(IndustryType industrytype, IndustryType entity)
        {
            industrytype.IndustryTypeDesc = entity.IndustryTypeDesc;
           
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(IndustryType industrytype)
        {
            // _TaxIntegrationContext.IndustryTypes.Remove(industrytype);
            industrytype.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }

    }
}
