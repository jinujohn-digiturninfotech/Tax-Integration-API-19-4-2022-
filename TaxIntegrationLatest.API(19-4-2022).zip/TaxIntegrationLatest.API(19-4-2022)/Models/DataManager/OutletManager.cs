﻿using System.Collections.Generic;
using System.Linq;
using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class OutletManager : IDataRepository<Outlet>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public OutletManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Outlet> GetAll()
        {
            return _TaxIntegrationContext.Outlets.Where(x => x.IsActive).ToList();
        }
        public Outlet Get(long id)
        {
            return _TaxIntegrationContext.Outlets.FirstOrDefault(e => e.ID == id);
        }
        public void Add(Outlet entity)
        {
            _TaxIntegrationContext.Outlets.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Outlet Outlet, Outlet entity)
        {
            Outlet.OutletName = entity.OutletName;
            Outlet.OutletSequence = entity.OutletSequence;
            Outlet.EntityID = entity.EntityID;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Outlet Outlet)
        {
            // _TaxIntegrationContext.Outlets.Remove(Outlet);
            Outlet.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
