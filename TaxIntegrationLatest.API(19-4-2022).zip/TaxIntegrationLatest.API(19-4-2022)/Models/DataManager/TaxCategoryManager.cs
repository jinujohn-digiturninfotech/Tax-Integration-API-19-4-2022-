﻿using System.Collections.Generic;
using System.Linq;
using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class TaxCategoryManager: IDataRepository<TaxCategory>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public TaxCategoryManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<TaxCategory> GetAll()
        {
            return _TaxIntegrationContext.TaxCategories.Where(x => x.IsActive).ToList();
        }
        public TaxCategory Get(long id)
        {
            return _TaxIntegrationContext.TaxCategories.FirstOrDefault(e => e.Id == id);
        }
        public void Add(TaxCategory entity)
        {
            _TaxIntegrationContext.TaxCategories.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(TaxCategory taxcategory, TaxCategory entity)
        {
            taxcategory.TaxCategoryDesc = entity.TaxCategoryDesc;
            taxcategory.TaxCategoryDescLocal = entity.TaxCategoryDescLocal;
            taxcategory.TaxPercentage = entity.TaxPercentage;
            taxcategory.Status = entity.Status;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(TaxCategory taxcategory)
        {
            //_TaxIntegrationContext.TaxCategories.Remove(taxcategory);
            taxcategory.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }

    }
}
