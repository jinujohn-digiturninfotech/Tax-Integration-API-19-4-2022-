﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class BankChargeManager :IDataRepository<BankCharge>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public BankChargeManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<BankCharge> GetAll()
        {
            return _TaxIntegrationContext.BankCharges.Where(x => x.IsActive).ToList();
        }
        public BankCharge Get(long id)
        {
            return _TaxIntegrationContext.BankCharges.FirstOrDefault(e => e.ID == id);
        }
        public void Add(BankCharge entity)
        {
            _TaxIntegrationContext.BankCharges.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(BankCharge BankCharge, BankCharge entity)
        {
            BankCharge.BankChargeDesc = entity.BankChargeDesc;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(BankCharge BankCharge)
        {
            // _TaxIntegrationContext.BankCharges.Remove(BankCharge);
            BankCharge.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
