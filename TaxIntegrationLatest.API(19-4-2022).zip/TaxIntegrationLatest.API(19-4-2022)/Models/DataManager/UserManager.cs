﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class UserManager: IDataRepository<User>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public UserManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<User> GetAll()
        {
            return _TaxIntegrationContext.Users.Where(x => x.IsActive).ToList();
        }
        public User Get(long id)
        {
            return _TaxIntegrationContext.Users.FirstOrDefault(e => e.Id == id);
        }
        public void Add(User entity)
        {
            _TaxIntegrationContext.Users.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(User user, User entity)
        {
            user.InviteStatus = entity.InviteStatus;
            user.EmailID = entity.EmailID;
           // user.RoleID = entity.RoleID;
           // user.OrganizationID = entity.OrganizationID;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(User user)
        {
            // _TaxIntegrationContext.Users.Remove(user);
            user.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
