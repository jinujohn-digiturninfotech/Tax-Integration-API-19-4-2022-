﻿using System.Collections.Generic;
using System.Linq;
using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class LocationManager: IDataRepository<Location>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public LocationManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Location> GetAll()
        {
            return _TaxIntegrationContext.Locations.Where(x => x.IsActive).ToList();
        }
        public Location Get(long id)
        {
            return _TaxIntegrationContext.Locations.FirstOrDefault(e => e.Id == id);
        }
        public void Add(Location entity)
        {
            _TaxIntegrationContext.Locations.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Location location, Location entity)
        {
            location.Locationdesc = entity.Locationdesc;
            location.Latitude = entity.Latitude;
            location.Longitude = entity.Longitude;

            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Location location)
        {
            //  _TaxIntegrationContext.Locations.Remove(location);
            location.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }

    }
}
