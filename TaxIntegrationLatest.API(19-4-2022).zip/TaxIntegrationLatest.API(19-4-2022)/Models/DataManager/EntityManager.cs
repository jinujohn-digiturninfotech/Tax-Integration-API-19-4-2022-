﻿using System.Collections.Generic;
using System.Linq;
using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class EntityManager : IDataRepository<Entity>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public EntityManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Entity> GetAll()
        {
            return _TaxIntegrationContext.Entities.Where(x => x.IsActive).ToList();
        }
        public Entity Get(long id)
        {
            return _TaxIntegrationContext.Entities.FirstOrDefault(e => e.Id == id);
        }
        public void Add(Entity entity)
        {
            _TaxIntegrationContext.Entities.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Entity Entity, Entity entity)
        {


            Entity.EntityName = entity.EntityName;
            Entity.EntityNameLocal = entity.EntityNameLocal;
            Entity.IndustryTypeID = entity.IndustryTypeID;
            Entity.BusinessLocationID = entity.BusinessLocationID;
            Entity.AddressID = entity.AddressID;
            Entity.SocialNetworkID = entity.SocialNetworkID;

            Entity.TRN_VAT_NO = entity.TRN_VAT_NO;
            Entity.TRN_Registration_Name = entity.TRN_Registration_Name;
            Entity.CR_Number = entity.CR_Number;
            Entity.CurrencyID = entity.CurrencyID;
            Entity.DefaultLanguageID = entity.DefaultLanguageID;

            Entity.Timezone = entity.Timezone;
            Entity.DateFormat = entity.DateFormat;
            Entity.OutletID = entity.OutletID;


            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Entity Entity)
        {
            //_TaxIntegrationContext.Entities.Remove(Entity);
            Entity.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
