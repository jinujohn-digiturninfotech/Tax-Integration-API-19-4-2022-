﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class ProductBatchManager:IDataRepository<ProductBatch>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public ProductBatchManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<ProductBatch> GetAll()
        {
            return _TaxIntegrationContext.ProductBatches.Where(x => x.IsActive).ToList();
        }
        public ProductBatch Get(long id)
        {
            return _TaxIntegrationContext.ProductBatches.FirstOrDefault(e => e.Id == id);
        }
        public void Add(ProductBatch entity)
        {
            _TaxIntegrationContext.ProductBatches.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(ProductBatch productbatch, ProductBatch entity)
        {
            productbatch.BatchNumber = entity.BatchNumber;
            productbatch.ExpiryDate = entity.ExpiryDate;
            productbatch.ManufactureDate = entity.ManufactureDate;
            productbatch.ShipmentNumber = entity.ShipmentNumber;
           // productbatch.ProductID = entity.ProductID;
           // productbatch.OrganizationID = entity.OrganizationID;
           _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(ProductBatch productbatch)
        {
            //  _TaxIntegrationContext.ProductBatches.Remove(productbatch);
            productbatch.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
