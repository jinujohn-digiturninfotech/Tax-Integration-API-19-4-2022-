﻿using System.Collections.Generic;
using System.Linq;
using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class LanguageManager: IDataRepository<Language>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public LanguageManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Language> GetAll()
        {
            return _TaxIntegrationContext.Languages.Where(x => x.IsActive).ToList();
        }
        public Language Get(long id)
        {
            return _TaxIntegrationContext.Languages.FirstOrDefault(e => e.Id == id);
        }
        public void Add(Language entity)
        {
            _TaxIntegrationContext.Languages.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Language language, Language entity)
        {
            language.LanguageName = entity.LanguageName;
            language.TextDirection = entity.TextDirection;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Language language)
        {
            // _TaxIntegrationContext.Languages.Remove(language);
            language.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }

    }
}
