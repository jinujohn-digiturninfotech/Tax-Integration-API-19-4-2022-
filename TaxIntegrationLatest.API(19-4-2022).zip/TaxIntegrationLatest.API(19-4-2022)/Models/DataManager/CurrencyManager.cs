﻿using System.Collections.Generic;
using System.Linq;
using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class CurrencyManager: IDataRepository<Currency>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public CurrencyManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Currency> GetAll()
        {
            return _TaxIntegrationContext.Currencies.Where(x => x.IsActive).ToList();
        }
        public Currency Get(long id)
        {
            return _TaxIntegrationContext.Currencies.FirstOrDefault(e => e.Id == id);
        }
        public void Add(Currency entity)
        {
            _TaxIntegrationContext.Currencies.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Currency currency, Currency entity)
        {
            currency.CurrencyName = entity.CurrencyName;
            
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Currency currency)
        {
            // _TaxIntegrationContext.Currencies.Remove(currency);
            currency.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }

    }
}
