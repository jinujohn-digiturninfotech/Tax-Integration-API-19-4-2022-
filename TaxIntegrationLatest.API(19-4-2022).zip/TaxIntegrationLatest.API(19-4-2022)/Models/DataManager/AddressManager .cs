﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class AddressManager : IDataRepository<Address>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public AddressManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Address> GetAll()
        {
            return _TaxIntegrationContext.Addresses.Where(x => x.IsActive).ToList();
        }
        public Address Get(long id)
        {
            return _TaxIntegrationContext.Addresses.FirstOrDefault(e => e.Id == id);
        }
        public void Add(Address entity)
        {
            _TaxIntegrationContext.Addresses.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Address address, Address entity)
        {
            address.BuildingNo = entity.BuildingNo;
            address.UnitNo = entity.UnitNo;
            address.AdditionalNo = entity.AdditionalNo;
            address.Street=entity.Street;
            address.District = entity.District;
            address.City = entity.City;
            address.County = entity.County;
            address.State = entity.State;
            address.Country = entity.Country;
            address.Postcode = entity.Postcode;
            address.PhoneNo = entity.PhoneNo;
            address.SecondaryPhoneNo=entity.SecondaryPhoneNo;

            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Address address)
        {
            //  _TaxIntegrationContext.Addresses.Remove(address);
            address.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }

    }
}
