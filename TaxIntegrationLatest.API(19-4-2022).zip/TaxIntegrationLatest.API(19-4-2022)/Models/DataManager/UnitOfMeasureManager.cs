﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class UnitOfMeasureManager:IDataRepository<UnitOfMeasure>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public UnitOfMeasureManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<UnitOfMeasure> GetAll()
        {
            return _TaxIntegrationContext.UnitOfMeasures.Where(x => x.IsActive).ToList();
        }
        public UnitOfMeasure Get(long id)
        {
            return _TaxIntegrationContext.UnitOfMeasures.FirstOrDefault(e => e.Id == id);
        }
        public void Add(UnitOfMeasure entity)
        {
            _TaxIntegrationContext.UnitOfMeasures.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(UnitOfMeasure unitofmeasure, UnitOfMeasure entity)
        {
            unitofmeasure.UnitDesc = entity.UnitDesc;
            unitofmeasure.UnitFactor = entity.UnitFactor;
            unitofmeasure.UnitAbbreviation = entity.UnitAbbreviation;
            //  unitofmeasure.OrganizationID = entity.OrganizationID;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(UnitOfMeasure unitofmeasure)
        {
            // _TaxIntegrationContext.UnitOfMeasures.Remove(unitofmeasure);
            unitofmeasure.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
