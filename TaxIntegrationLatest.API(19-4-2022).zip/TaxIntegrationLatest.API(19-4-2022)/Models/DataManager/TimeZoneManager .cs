﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class TimeZoneManager: IDataRepository<TimeZoneDetails>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public TimeZoneManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<TimeZoneDetails> GetAll()
        {
            return _TaxIntegrationContext.TimeZones.Where(x => x.IsActive).ToList();
        }
        public TimeZoneDetails Get(long id)
        {
            return _TaxIntegrationContext.TimeZones.FirstOrDefault(e => e.Id == id);
        }
        public void Add(TimeZoneDetails entity)
        {
            _TaxIntegrationContext.TimeZones.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(TimeZoneDetails timezonedetails, TimeZoneDetails entity)
        {
            timezonedetails.ZoneName = entity.ZoneName;
            timezonedetails.ZoneAbbreviation = entity.ZoneAbbreviation;
            timezonedetails.UTCDifference = entity.UTCDifference;
            timezonedetails.DisplayName = entity.DisplayName;
            timezonedetails.UpdatedOn = entity.UpdatedOn;
            timezonedetails.UpdatedBy = entity.UpdatedBy;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(TimeZoneDetails timezonedetails)
        {
            // _TaxIntegrationContext.TimeZones.Remove(timezonedetails);
            timezonedetails.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }

    }
}
