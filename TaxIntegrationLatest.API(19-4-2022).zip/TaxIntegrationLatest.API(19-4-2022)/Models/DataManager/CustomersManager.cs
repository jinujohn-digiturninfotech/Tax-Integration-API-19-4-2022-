﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class CustomersManager: IDataRepository<Customers>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public CustomersManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Customers> GetAll()
        {
            return _TaxIntegrationContext.Customerss.Where(x => x.IsActive).ToList();
        }
        public Customers Get(long id)
        {
            return _TaxIntegrationContext.Customerss.FirstOrDefault(e => e.Id == id);
        }
        public void Add(Customers entity)
        {
            _TaxIntegrationContext.Customerss.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Customers customers, Customers entity)
        {
          // customers.CustomerCategoryID = entity.CustomerCategoryID;
          customers.Status=entity.Status;
            customers.CustomerName=entity.CustomerName;
            customers.CustomerNameLocal=entity.CustomerNameLocal;
            //customers.AddressID=entity.AddressID;
            customers.TRN_No=entity.TRN_No;
            customers.RegistrationNo=entity.RegistrationNo;
            //customers.TaxCategoryID=entity.TaxCategoryID;
            customers.CreditEligibility=entity.CreditEligibility;
            customers.CreditAccountNo=entity.CreditAccountNo;
           // customers.CurrencyID=entity.CurrencyID;
          // customers.OrganizationID=entity.OrganizationID;

            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Customers customers)
        {
            // _TaxIntegrationContext.Customerss.Remove(customers);
            customers.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
