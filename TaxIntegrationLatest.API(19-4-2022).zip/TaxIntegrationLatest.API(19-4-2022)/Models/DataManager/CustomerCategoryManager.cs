﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class CustomerCategoryManager:IDataRepository<CustomerCategory>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public CustomerCategoryManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<CustomerCategory> GetAll()
        {
            return _TaxIntegrationContext.CustomerCategories.Where(x => x.IsActive).ToList();
        }
        public CustomerCategory Get(long id)
        {
            return _TaxIntegrationContext.CustomerCategories.FirstOrDefault(e => e.Id == id);
        }
        public void Add(CustomerCategory entity)
        {
            _TaxIntegrationContext.CustomerCategories.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(CustomerCategory customercategory, CustomerCategory entity)
        {
            customercategory.CategoryDesc = entity.CategoryDesc;

            // customercategory.OrganizationID = entity.OrganizationID;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(CustomerCategory customercategory)
        {
            // _TaxIntegrationContext.CustomerCategories.Remove(customercategory);
            customercategory.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
