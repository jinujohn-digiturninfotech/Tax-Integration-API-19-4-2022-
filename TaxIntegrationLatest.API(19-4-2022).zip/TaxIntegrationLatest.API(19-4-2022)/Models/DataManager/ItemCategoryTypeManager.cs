﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class ItemCategoryTypeManager: IDataRepository<ItemCategoryType>
    {

        readonly TaxIntegrationContext _TaxIntegrationContext;
        public ItemCategoryTypeManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<ItemCategoryType> GetAll()
        {
            return _TaxIntegrationContext.ItemCategoryTypes.Where(x => x.IsActive).ToList();
        }
        public ItemCategoryType Get(long id)
        {
            return _TaxIntegrationContext.ItemCategoryTypes.FirstOrDefault(e => e.Id == id);
        }
        public void Add(ItemCategoryType entity)
        {
            _TaxIntegrationContext.ItemCategoryTypes.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(ItemCategoryType itemcategorytype, ItemCategoryType entity)
        {
            itemcategorytype.CategoryTypeDesc = entity.CategoryTypeDesc;
            itemcategorytype.Status = entity.Status;
            // ItemCategoryType.OrganizationID = entity.OrganizationID;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(ItemCategoryType itemcategorytype)
        {
            //_TaxIntegrationContext.ItemCategoryTypes.Remove(itemcategorytype);
            itemcategorytype.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
