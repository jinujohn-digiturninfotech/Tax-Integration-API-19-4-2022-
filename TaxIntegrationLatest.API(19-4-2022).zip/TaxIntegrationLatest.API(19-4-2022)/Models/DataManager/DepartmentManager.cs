﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class DepartmentManager:IDataRepository<Department>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public DepartmentManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Department> GetAll()
        {
            return _TaxIntegrationContext.Departments.Where(x => x.IsActive).ToList();
        }
        public Department Get(long id)
        {
            return _TaxIntegrationContext.Departments.FirstOrDefault(e => e.Id == id);
        }
        public void Add(Department entity)
        {
            _TaxIntegrationContext.Departments.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Department department, Department entity)
        {
            department.DepartmentName = entity.DepartmentName;
           
            // Department.OrganizationID = entity.OrganizationID;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Department department)
        {
            //  _TaxIntegrationContext.Departments.Remove(department);
            department.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
