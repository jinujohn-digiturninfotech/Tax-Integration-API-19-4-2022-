﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class ActivityManager:IDataRepository<Activity>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public ActivityManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Activity> GetAll()
        {
            return _TaxIntegrationContext.Activities.Where(x => x.IsActive).ToList();
            // return _TaxIntegrationContext.Activities.ToList();
        }
        public Activity Get(long id)
        {
            return _TaxIntegrationContext.Activities.FirstOrDefault(e => e.Id == id);
        }
        public void Add(Activity entity)
        {
            _TaxIntegrationContext.Activities.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Activity activity, Activity entity)
        {
            activity.ActivityDesc = entity.ActivityDesc;
            activity.Status = entity.Status;
           // activity.OrganizationID = entity.OrganizationID;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Activity activity)
        {
            //_TaxIntegrationContext.Activities.Remove(activity);
            activity.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }

    
}
}
