﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class BankAccountsManager:IDataRepository<BankAccounts>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public BankAccountsManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<BankAccounts> GetAll()
        {
            return _TaxIntegrationContext.BankAccountss.Where(x => x.IsActive).ToList();
        }
        public BankAccounts Get(long id)
        {
            return _TaxIntegrationContext.BankAccountss.FirstOrDefault(e => e.Id == id);
        }
        public void Add(BankAccounts entity)
        {
            _TaxIntegrationContext.BankAccountss.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(BankAccounts bankaccounts, BankAccounts entity)
        {
            bankaccounts.BankName = entity.BankName;
            bankaccounts.BeneficiaryName = entity.BeneficiaryName;
            bankaccounts.AccountNumber = entity.AccountNumber;
            bankaccounts.IBAN_NO = entity.IBAN_NO;
            bankaccounts.BankChargeDesc = entity.BankChargeDesc;
            bankaccounts.BankChargeRate = entity.BankChargeRate;
            // bankaccounts.OrganizationID = entity.OrganizationID;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(BankAccounts bankaccounts)
        {
            // _TaxIntegrationContext.BankAccountss.Remove(bankaccounts);
            bankaccounts.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
