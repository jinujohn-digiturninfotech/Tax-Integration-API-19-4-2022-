﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class UserRolesManager:IDataRepository<UserRoles>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public UserRolesManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<UserRoles> GetAll()
        {
            return _TaxIntegrationContext.UserRoless.Where(x => x.IsActive).ToList();
        }
        public UserRoles Get(long id)
        {
            return _TaxIntegrationContext.UserRoless.FirstOrDefault(e => e.Id == id);
        }
        public void Add(UserRoles entity)
        {
            _TaxIntegrationContext.UserRoless.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(UserRoles userroles, UserRoles entity)
        {
            userroles.RoleDesc = entity.RoleDesc;
            userroles.Status = entity.Status;
            userroles.AccountAccess = entity.AccountAccess;
            userroles.ReportAccess = entity.ReportAccess;
            userroles.InventoryAccess = entity.InventoryAccess;
            userroles.UserManagementAccess = entity.UserManagementAccess;
            userroles.MasterAccess = entity.MasterAccess;

            // userroles.OrganizationID = entity.OrganizationID;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(UserRoles userroles)
        {
            //_TaxIntegrationContext.UserRoless.Remove(userroles);
            userroles.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
