﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class ItemCategoryManager: IDataRepository<ItemCategory>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public ItemCategoryManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<ItemCategory> GetAll()
        {
            return _TaxIntegrationContext.ItemCategories.Where(x => x.IsActive).ToList();
        }
        public ItemCategory Get(long id)
        {
            return _TaxIntegrationContext.ItemCategories.FirstOrDefault(e => e.Id == id);
        }
        public void Add(ItemCategory entity)
        {
            _TaxIntegrationContext.ItemCategories.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(ItemCategory itemcategory, ItemCategory entity)
        {
            itemcategory.CategoryDesc = entity.CategoryDesc;
            itemcategory.CategoryDescLocal = entity.CategoryDescLocal;
            itemcategory.CategorySummary = entity.CategorySummary;
            itemcategory.Status = entity.Status;
           // itemcategory.CategoryTypeID = entity.CategoryTypeID;
           // itemcategory.OrganizationID = entity.OrganizationID;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(ItemCategory itemcategory)
        {

            //_TaxIntegrationContext.ItemCategories.Remove(itemcategory);
            itemcategory.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
