﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class EmployeeManager:IDataRepository<Employee>
    {
       
            readonly TaxIntegrationContext _TaxIntegrationContext;
            public EmployeeManager(TaxIntegrationContext context)
            {
                _TaxIntegrationContext = context;
            }
            public IEnumerable<Employee> GetAll()
            {
                return _TaxIntegrationContext.Employees.Where(x => x.IsActive).ToList();
            }
            public Employee Get(long id)
            {
                return _TaxIntegrationContext.Employees.FirstOrDefault(e => e.Id == id);
            }
            public void Add(Employee entity)
            {
                _TaxIntegrationContext.Employees.Add(entity);
                _TaxIntegrationContext.SaveChanges();
            }
            public void Update(Employee employee, Employee entity)
            {
                employee. Status= entity.Status;
                employee.EmployeeName = entity.EmployeeName;
            employee.EmployeeNameLocal = entity.EmployeeNameLocal;
          //  employee.AddressID = entity.AddressID;
          //  employee.DepartmentID = entity.DepartmentID;
           // employee.PositionID = entity.PositionID;
           // employee.AddressID= entity.AddressID;
           // employee.ReportingManagerID = entity.ReportingManagerID;
            employee.CostPerHour = entity.CostPerHour;
            employee.CostSelling= entity.CostSelling;
            employee.TimesheetLimit= entity.TimesheetLimit;
           // employee.CurrencyID = entity.CurrencyID;
            // employee.OrganizationID = entity.OrganizationID;
                _TaxIntegrationContext.SaveChanges();
            }
            public void Delete(Employee employee)
            {
            //_TaxIntegrationContext.Employees.Remove(employee);
            employee.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
            }
        }
}
