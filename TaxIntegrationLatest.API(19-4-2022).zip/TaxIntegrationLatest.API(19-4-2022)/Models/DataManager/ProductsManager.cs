﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class ProductsManager:IDataRepository<Products>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public ProductsManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Products> GetAll()
        {
            return _TaxIntegrationContext.Productss.Where(x => x.IsActive).ToList();
        }
        public Products Get(long id)
        {
            return _TaxIntegrationContext.Productss.FirstOrDefault(e => e.Id == id);
        }
        public void Add(Products entity)
        {
            _TaxIntegrationContext.Productss.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Products products, Products entity)
        {
            products.ProductDesc = entity.ProductDesc;
            products.ProductDescLocal = entity.ProductDescLocal;
            products.ProductSummary = entity.ProductSummary;
           // products.ItemCategoryID = entity.ItemCategoryID;
           products.StockAvailable = entity.StockAvailable;
           // products.StockUnitID= entity.StockUnitID;
           products.PurchasePricePerUnit = entity.PurchasePricePerUnit;
            products.SellingPricePerUnit = entity.SellingPricePerUnit; 
            products.SellingPriceOverride=entity.SellingPriceOverride;
           // products.OrganizationID = entity.OrganizationID;
           products.Barcode= entity.Barcode;
           // products.TaxCategoryID = entity.TaxCategoryID;
           products.DiscountEligibility= entity.DiscountEligibility; ;
            products.Status= entity.Status;
           // products.BatchID= entity.BatchID;
           products.ProductCode= entity.ProductCode;

            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Products products)
        {
            //  _TaxIntegrationContext.Productss.Remove(products);
            products.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
