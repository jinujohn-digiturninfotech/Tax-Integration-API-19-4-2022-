﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class PositionManager: IDataRepository<Position>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public PositionManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Position> GetAll()
        {
            return _TaxIntegrationContext.Positions.Where(x => x.IsActive).ToList();
        }
        public Position Get(long id)
        {
            return _TaxIntegrationContext.Positions.FirstOrDefault(e => e.Id == id);
        }
        public void Add(Position entity)
        {
            _TaxIntegrationContext.Positions.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Position position, Position entity)
        {
            position.PositionDesc = entity.PositionDesc;
            position.IsManager = entity.IsManager;
          //  position.OrganizationID = entity.OrganizationID;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Position position)
        {
            // _TaxIntegrationContext.Positions.Remove(position);
            position.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }

    }
}
