﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class SocialNetworkManager: IDataRepository<SocialNetwork>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public SocialNetworkManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<SocialNetwork> GetAll()
        {
            return _TaxIntegrationContext.SocialNetworks.Where(x => x.IsActive).ToList();
        }
        public SocialNetwork Get(long id)
        {
            return _TaxIntegrationContext.SocialNetworks.FirstOrDefault(e => e.Id == id);
        }
        public void Add(SocialNetwork entity)
        {
            _TaxIntegrationContext.SocialNetworks.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(SocialNetwork socialnetwork, SocialNetwork entity)
        {
            socialnetwork.FacebookPage = entity.FacebookPage;
            socialnetwork.TwitterHandle = entity.TwitterHandle;
            socialnetwork.InstaPage = entity.InstaPage;
            socialnetwork.Website=entity.Website;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(SocialNetwork socialnetwork)
        {
            //_TaxIntegrationContext.SocialNetworks.Remove(socialnetwork);
            socialnetwork.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }

    }
}
