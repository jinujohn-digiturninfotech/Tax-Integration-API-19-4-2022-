﻿using System.Collections.Generic;
using System.Linq;
using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;

namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class OrganizationManager :IDataRepository<Organization>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public OrganizationManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Organization> GetAll()
        {
            return _TaxIntegrationContext.Organizations.Where(x => x.IsActive).ToList();
        }
        public Organization Get(long id)
        {
            return _TaxIntegrationContext.Organizations.FirstOrDefault(e => e.Id == id);
        }
        public void Add(Organization entity)
        {
            _TaxIntegrationContext.Organizations.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Organization Organization, Organization entity)
        {
            Organization.OrganizationName = entity.OrganizationName;
            Organization.OrganizationNameLocal = entity.OrganizationNameLocal;
            Organization.IndustryTypeID = entity.IndustryTypeID;
            Organization.BusinessLocationID = entity.BusinessLocationID;
            Organization.AddressID = entity.AddressID;
            Organization.SocialNetworkID = entity.SocialNetworkID;
            Organization.TRN_VAT_NO = entity.TRN_VAT_NO;
            Organization.TRN_Registration_Name = entity.TRN_Registration_Name;
            Organization.CR_Number = entity.CR_Number;
            Organization.CurrencyID = entity.CurrencyID;
            Organization.DefaultLanguageID = entity.DefaultLanguageID;
            Organization.DateFormat = entity.DateFormat;
            Organization.EntitiesAvailable = entity.EntitiesAvailable;

            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Organization Organization)
        {
            // _TaxIntegrationContext.Organizations.Remove(Organization);
            Organization.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
