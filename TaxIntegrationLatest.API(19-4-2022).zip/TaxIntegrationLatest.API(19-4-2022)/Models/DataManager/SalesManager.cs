﻿using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class SalesManager:IDataRepository<Sales>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public SalesManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<Sales> GetAll()
        {
            return _TaxIntegrationContext.Saless.Where(x => x.IsActive).ToList();
        }
        public Sales Get(long id)
        {
            return _TaxIntegrationContext.Saless.FirstOrDefault(e => e.Id == id);
        }
        public void Add(Sales entity)
        {
            _TaxIntegrationContext.Saless.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(Sales sales, Sales entity)
        {
           // sales.ProductID = entity.ProductID;
            sales.ProductDesc = entity.ProductDesc;
           // sales.Quantity = entity.Quantity;
            sales.DiscountPercentage = entity.DiscountPercentage;
            sales.DiscountAmount = entity.DiscountAmount;
            sales.SalesAmount= entity.SalesAmount;
            sales. InvoiceNumber= entity.InvoiceNumber;
            sales.QuotationNumber = entity.QuotationNumber;
           // sales.TaxCategoryID = entity.TaxCategoryID;


            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(Sales sales)
        {
            // _TaxIntegrationContext.Saless.Remove(sales);
            sales.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
