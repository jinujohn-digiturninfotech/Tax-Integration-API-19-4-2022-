﻿using System.Collections.Generic;
using System.Linq;
using TaxIntegrationLatest.API.Data;
using TaxIntegrationLatest.API.Models.Repository;
namespace TaxIntegrationLatest.API.Models.DataManager
{
    public class PaymentMethodManager : IDataRepository<PaymentMethod>
    {
        readonly TaxIntegrationContext _TaxIntegrationContext;
        public PaymentMethodManager(TaxIntegrationContext context)
        {
            _TaxIntegrationContext = context;
        }
        public IEnumerable<PaymentMethod> GetAll()
        {
            return _TaxIntegrationContext.PaymentMethods.Where(x => x.IsActive).ToList();
        }
        public PaymentMethod Get(long id)
        {
            return _TaxIntegrationContext.PaymentMethods.FirstOrDefault(e => e.Id == id);
        }
        public void Add(PaymentMethod entity)
        {
            _TaxIntegrationContext.PaymentMethods.Add(entity);
            _TaxIntegrationContext.SaveChanges();
        }
        public void Update(PaymentMethod PaymentMethod, PaymentMethod entity)
        {
            PaymentMethod.PaymentMethodDesc = entity.PaymentMethodDesc;
            PaymentMethod.Code = entity.Code;
            _TaxIntegrationContext.SaveChanges();
        }
        public void Delete(PaymentMethod PaymentMethod)
        {
            // _TaxIntegrationContext.PaymentMethods.Remove(PaymentMethod);
            PaymentMethod.IsActive = false;
            _TaxIntegrationContext.SaveChanges();
        }
    }
}
