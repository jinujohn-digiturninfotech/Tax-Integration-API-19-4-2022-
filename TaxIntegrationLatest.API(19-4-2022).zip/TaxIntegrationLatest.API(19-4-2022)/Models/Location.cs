﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models
{
    public class Location
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter Location Description")]
        [Column(TypeName = "nvarchar(100)")]
        public string? Locationdesc { get; set; }

        //[Required]
        [Column(TypeName = "decimal(8,4)")]
        public decimal Latitude { get; set; }
       // [Required]
        [Column(TypeName = "decimal(8,4)")]
        public decimal Longitude { get; set; }
        public Boolean IsActive { get; set; }
        //[JsonIgnore]
        //public virtual Location? Organization { get; set; }
        public virtual Organization? organization { get; set; }
    }
}
