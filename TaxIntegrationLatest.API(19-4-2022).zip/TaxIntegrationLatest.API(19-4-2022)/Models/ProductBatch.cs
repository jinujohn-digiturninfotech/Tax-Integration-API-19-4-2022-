﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class ProductBatch
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(10)")]
        public string? BatchNumber { get; set; }

        [Required]
        [Column(TypeName = "datetime")]
        public DateTime ExpiryDate { get; set; }
        [Required]
        [Column(TypeName = "datetime")]
        public DateTime ManufactureDate { get; set; }
        [Column(TypeName = "nvarchar(20)")]
        public string? ShipmentNumber { get; set; }

       // [ForeignKey("Products")]
        public int ProductID { get; set; }

      //  [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
        // public virtual Products? Products { get; set; }
       // [JsonIgnore]
        //public virtual Organization? Organization { get; set; }

    }
}
