﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models
{
    public class Position
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Column(TypeName = "nvarchar(200)")]
        public string? PositionDesc { get; set; }
        
       // [Column(TypeName = "bit")]
        public Boolean IsManager { get; set; }

       // [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
       // [JsonIgnore]
       // public virtual Organization? Organization { get; set; }
        public virtual Employee? employee { get; set; }
    }
}
