﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class Products
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(200)")]
        public string? ProductDesc { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string? ProductDescLocal { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string? ProductSummary { get; set; }

       // [ForeignKey("ItemCategory")]
        public int ItemCategoryID { get; set; }
        
        
        [Column(TypeName = "Decimal(8,2)")]
        public Decimal StockAvailable { get; set; }

     //   [ForeignKey("UnitOfMeasure")]
        public int StockUnitID { get; set; }

        [Column(TypeName = "Decimal(8,2)")]
        public Decimal PurchasePricePerUnit { get; set; }
        [Column(TypeName = "Decimal(8,2)")]
        public Decimal SellingPricePerUnit { get; set; }
       // [Column(TypeName = "bit")]
        public Boolean SellingPriceOverride { get; set; }

       // [ForeignKey("Organization")]
        public int OrganizationID { get; set; }

        [Column(TypeName = "nvarchar(200)")]
        public string? Barcode { get; set; }

      //  [ForeignKey("TextCategory")]
        public int TaxCategoryID { get; set; }

       // [Column(TypeName = "bit")]
        public Boolean DiscountEligibility { get; set; }
       // [Column(TypeName = "bit")]
        public Boolean Status { get; set; }

      //  [ForeignKey("ProductBatch")]
        public int BatchID { get; set; }
        [Column(TypeName = "nvarchar(10)")]
        public string? ProductCode { get; set; }
        public Boolean IsActive { get; set; }

        

    }
}
