﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models
{
    public class Address
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }
        //[StringLength(6, MinimumLength = 6)]
        //[Range(6, 6)]
        [Required( ErrorMessage = "BuildingNo field must have 6 Value!")]
        public int BuildingNo { get; set; }

        //[StringLength(6, MinimumLength = 6)]
       // [Range(6, 6)]
        [Required(ErrorMessage = "UnitNo field must have 6 Value!")]
        public int UnitNo { get; set; }

        //  [StringLength(6, MinimumLength = 6)]
        //[Range(6, 6)]
        [Required(ErrorMessage = "AdditionalNo field must have 6 Value!")]
        public int AdditionalNo { get; set; }
        
       
        [Column(TypeName = "nvarchar(100)")]
        public string? Street { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string? District { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string?City  { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string? County { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string? State { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string? Country { get; set; }
        
        [Column(TypeName = "nvarchar(15)")]
        public string? Postcode { get; set; }
        //  [DataType(DataType.PhoneNumber)]
        // [StringLength(10, MinimumLength = 10)]
        //[Range(10,10)]
       // [RegularExpression("^[0-9]*$")]
        [Required(ErrorMessage = "PhoneNo field must have 10 digit value!")]
        public int PhoneNo { get; set; }
        // [StringLength(10, MinimumLength = 10)]
        // [DataType(DataType.PhoneNumber)]
        // [Range(10,10)]
       // [RegularExpression("^[0-9]*$")]
        [Required(ErrorMessage = "SecondaryPhoneNo field must have 10 digit value !")]
        
        public int SecondaryPhoneNo { get; set; }
        public Boolean IsActive { get; set; }
       

        public virtual Employee? employee { get; set; }
        public virtual Organization? organization { get; set; }

    }
}
