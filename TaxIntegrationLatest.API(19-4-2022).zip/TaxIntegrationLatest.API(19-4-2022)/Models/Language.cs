﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models
{
    public class Language
    {


        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter Language Name")]
        [Column(TypeName = "nvarchar(100)")]
        public string? LanguageName { get; set; }

        [Required]
        [Column(TypeName = "char(3)")]
        public string TextDirection { get; set; }
        public Boolean IsActive { get; set; }
        //[JsonIgnore]
        //public virtual Language? Organization { get; set; }
        public virtual Organization? organization { get; set; }

    }
}
