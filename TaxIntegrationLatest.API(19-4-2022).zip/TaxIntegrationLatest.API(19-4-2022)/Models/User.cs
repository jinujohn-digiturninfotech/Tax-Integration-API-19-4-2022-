﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(20)")]
        public string? InviteStatus { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string? EmailID { get; set; }

      //  [ForeignKey("UserRoles")]
        public int RoleID { get; set; }

       // [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
        


    }
}
