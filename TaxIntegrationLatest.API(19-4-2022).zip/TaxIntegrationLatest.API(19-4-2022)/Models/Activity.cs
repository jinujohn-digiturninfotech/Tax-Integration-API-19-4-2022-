﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class Activity
    {


        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter Activity Name")]
        [Column(TypeName = "nvarchar(200)")]
        public string? ActivityDesc { get; set; }

        [Required]
      
        public Boolean Status { get; set; }
       // [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        

        public Boolean IsActive { get; set; }
       
        public virtual Employee? employee { get; set; }
    }
}
