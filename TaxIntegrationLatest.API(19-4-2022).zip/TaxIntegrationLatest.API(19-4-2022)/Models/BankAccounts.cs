﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class BankAccounts
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter Bank Name")]
        [Column(TypeName = "nvarchar(100)")]
        public string? BankName { get; set; }
        [Required(ErrorMessage = "Please Enter BeneficiaryName")]
        [Column(TypeName = "nvarchar(100)")]
        public string? BeneficiaryName { get; set; }
        
        [Required]
        public int AccountNumber { get; set; }
        [Required(ErrorMessage = "Please Enter IBAN_NO")]
        [Column(TypeName = "nvarchar(100)")]
        public string? IBAN_NO { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string? BankChargeDesc { get; set; }
        [Column(TypeName = "decimal(6,2)")]
        public decimal BankChargeRate { get; set; }
      //  [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
        //[JsonIgnore]
        //public virtual Organization? Organization { get; set; }

    }
}
