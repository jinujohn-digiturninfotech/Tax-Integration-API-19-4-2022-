﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class Entity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EntitySequence { get; set; }

        [Required(ErrorMessage = "Please Enter Entity Name")]
        [Column(TypeName = "nvarchar(200)")]
        public string? EntityName { get; set; }

        [Required(ErrorMessage = "Please Enter Local Name")]
        [Column(TypeName = "nvarchar(300)")]
        public string? EntityNameLocal { get; set; }
      
       // [ForeignKey("IndustryType")]
        public int IndustryTypeID { get; set; }

        //[ForeignKey("Location")]
        public int BusinessLocationID { get; set; }

        //[ForeignKey("Address")]
        public int AddressID { get; set; }
       
        //[ForeignKey("SocialNetwork")]
        public int SocialNetworkID { get; set; }

        [Required(ErrorMessage = "Please Enter TRN_VAT_NO Name")]
        [Column(TypeName = "nvarchar(20)")]
        public string? TRN_VAT_NO { get; set; }

        [Required(ErrorMessage = "Please Enter TRN Registration Name")]
        [Column(TypeName = "nvarchar(200)")]
        public string? TRN_Registration_Name { get; set; }

        [Required(ErrorMessage = "Please Enter CR Number Name")]
        [Column(TypeName = "nvarchar(25)")]
        public string? CR_Number { get; set; }

        //[ForeignKey("Currency")]
        public int CurrencyID { get; set; }


        //[ForeignKey("Language")]
        public int DefaultLanguageID { get; set; }

        [Required(ErrorMessage = "Please Enter Time Zone")]
        [Column(TypeName = "nvarchar(200)")]
        public string? Timezone { get; set; }

        [Required(ErrorMessage = "Please Enter Dateformat")]
        [Column(TypeName = "nvarchar(30)")]
        public string? DateFormat { get; set; }

        //[ForeignKey("Outlet")]
        public int OutletID { get; set; }
        
       // [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
       // [JsonIgnore]
        //public virtual Organization? Organization { get; set; }
       // public virtual IndustryType? IndustryType { get; set; }
       // public virtual Location? Location { get; set; }
        //public virtual Address? Address { get; set; }
        //public virtual SocialNetwork? SocialNetwork { get; set; }
        //public virtual Currency? Currency { get; set; }
        //public virtual Language? Language { get; set; }
      //  public virtual Outlet? Outlet { get; set; }
      //  public virtual Entity? outlet { get; set; }

    }
}
