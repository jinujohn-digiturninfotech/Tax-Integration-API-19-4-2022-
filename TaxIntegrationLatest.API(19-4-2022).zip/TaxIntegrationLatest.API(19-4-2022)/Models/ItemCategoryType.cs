﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class ItemCategoryType
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter ItemCategoryType Name")]
        [Column(TypeName = "nvarchar(200)")]
        public string? CategoryTypeDesc { get; set; }

        [Required]
        //[Column(TypeName = "bit")]
        public Boolean Status { get; set; }

       // [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
      //  [JsonIgnore]
        //public virtual Organization? Organization { get; set; }

    }
}
