﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models
{
    public class UserRoles
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string? RoleDesc { get; set; }

       // [Column(TypeName = "bit")]
        public Boolean Status { get; set; }
       // [Column(TypeName = "bit")]
        public Boolean AccountAccess { get; set; }
       // [Column(TypeName = "bit")]
        public Boolean ReportAccess { get; set; }
       // [Column(TypeName = "bit")]
        public Boolean InventoryAccess { get; set; }
       
       // [Column(TypeName = "bit")]
        public Boolean UserManagementAccess { get; set; }
        
      //  [Column(TypeName = "bit")]
        public Boolean MasterAccess { get; set; }

      //  [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
        //[JsonIgnore]
       

    }
}
