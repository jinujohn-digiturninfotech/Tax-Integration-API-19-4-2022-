﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models

{
    public class BankCharge
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int ID { get; set; }

        [Required(ErrorMessage = "Please Enter Bank Charge Name")]
        [Column(TypeName = "nvarchar(200)")]
        public string? BankChargeDesc { get; set; }
        
       // [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
        //[JsonIgnore]
        //public virtual Organization? Organization { get; set; }

    }
}
