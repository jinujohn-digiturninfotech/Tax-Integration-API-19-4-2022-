﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class Customers
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

      //  [ForeignKey("CustomerCategory")]
        public int CustomerCategoryID { get; set; }
       // [Column(TypeName = "bit")]
        public Boolean Status { get; set; }

        [Column(TypeName = "nvarchar(200)")]
        public string? CustomerName { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string?CustomerNameLocal { get; set; }
        
      //  [ForeignKey("Address")]
        public int AddressID { get; set; }
        [Column(TypeName = "nvarchar(20)")]
        public string? TRN_No { get; set; }
        [Column(TypeName = "nvarchar(20)")]
        public string? RegistrationNo { get; set; }

       // [ForeignKey("TextCategory")]
        public int TaxCategoryID { get; set; }
     //   [Column(TypeName = "bit")]
        public Boolean CreditEligibility { get; set; }


        

        [Column(TypeName = "nvarchar(20)")]
        public string? CreditAccountNo { get; set; }

      //  [ForeignKey("Currency")]
        public int CurrencyID { get; set; }
       // [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }

        //  public virtual CustomerCategory? CustomerCategory { get; set; }
        //public virtual Address? Address { get; set; }
        //public virtual TaxCategory? TaxCategory { get; set; }
        //public virtual Currency? Currency { get; set; }
       // [JsonIgnore]
        //public virtual Organization? Organization { get; set; }
      

    }
}
