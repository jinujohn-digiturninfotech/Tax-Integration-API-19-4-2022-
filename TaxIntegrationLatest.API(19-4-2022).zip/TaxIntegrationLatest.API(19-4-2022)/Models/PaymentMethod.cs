﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class PaymentMethod
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter Payment Method Name")]
        [Column(TypeName = "nvarchar(100)")]
        public string? PaymentMethodDesc { get; set; }

        public int Code { get; set; }

       // [ForeignKey("BankCharge")]
        public int BankChargeID { get; set; }

      //  [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
      //  [JsonIgnore]
        //public virtual Organization? Organization { get; set; }
      //  public virtual BankCharge? BankCharge { get; set; }


    }
}
