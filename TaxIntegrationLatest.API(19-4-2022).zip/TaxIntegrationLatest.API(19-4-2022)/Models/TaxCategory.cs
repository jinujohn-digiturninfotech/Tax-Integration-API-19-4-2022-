﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models
{
    public class TaxCategory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter TaxtCategory  Description")]
        [Column(TypeName = "nvarchar(100)")]
        public string? TaxCategoryDesc { get; set; }
        [Required(ErrorMessage = "Please Enter TaxCategory  Description Local")]
        [Column(TypeName = "nvarchar(100)")]
        public string? TaxCategoryDescLocal { get; set; }

        //[Required]
        [Column(TypeName = "decimal(5,2)")]
        public decimal TaxPercentage { get; set; }
        // [Required]
       // [Column(TypeName = "bit")]
        public Boolean Status { get; set; }
        public Boolean IsActive { get; set; }
    }
}
