﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class CustomerCategory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter CustomerCategory Description")]
        [Column(TypeName = "nvarchar(200)")]
        public string? CategoryDesc { get; set; }

      //  [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
       // [JsonIgnore]
        //public virtual Organization? Organization { get; set; }

    }
}
