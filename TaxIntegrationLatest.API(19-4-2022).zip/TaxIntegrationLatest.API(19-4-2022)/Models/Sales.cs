﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class Sales
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

       // [ForeignKey("Products")]
        public int ProductID { get; set; }

        [Column(TypeName = "nvarchar(200)")]
        public string? ProductDesc { get; set; }

        //[ForeignKey("UnitOfMeasure")]
        public int Quantity { get; set; }

        [Column(TypeName = "Decimal(5,2)")]
        public Decimal DiscountPercentage { get; set; }
        

        [Column(TypeName = "Decimal(8,2)")]
        public Decimal DiscountAmount { get; set; }
        [Column(TypeName = "Decimal(8,2)")]
        public Decimal SalesAmount { get; set; }

        [Column(TypeName = "nvarchar(25)")]
        public string? InvoiceNumber { get; set; }

        [Column(TypeName = "nvarchar(15)")]
        public string? QuotationNumber { get; set; }

        //[ForeignKey("TaxCategory")]
        public int TaxCategoryID { get; set; }
        public Boolean IsActive { get; set; }

      

    }
}
