﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
namespace TaxIntegrationLatest.API.Models
{
    public class Employee
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        [Required]
        public int Id { get; set; }

        [Column(TypeName = "bit")]
        public Boolean Status { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string? EmployeeName { get; set; }
        [Column(TypeName = "nvarchar(200)")]
        public string? EmployeeNameLocal { get; set; }

        [Required]
        [ForeignKey("Address")]
        public int AddressID { get; set; }
        public virtual Address? Address { get; set; }

        [Required]
        [ForeignKey("Department")]
        public int DepartmentID { get; set; }
        public virtual Department? Department { get; set; }

        [Required]
        [ForeignKey("Position")]
        public int PositionID { get; set; }
        public virtual Position? Position { get; set; }

        [Required]
        [ForeignKey("Activity")]
        public int ActivityID { get; set; }
        public virtual Activity? Activity { get; set; }

        
       [Required]
       // [ForeignKey("Employee")]
        
        public int? ReportingManagerID { get; set; }
        public virtual Employee Reporting { get; set; }

        [Column(TypeName = "Decimal(8,2)")]
        public Decimal CostPerHour { get; set; }


        [Column(TypeName = "Decimal(8,2)")]
        public Decimal CostSelling { get; set; }


        public int TimesheetLimit { get; set; }

        [Required]
        [ForeignKey("Currency")]
        public int CurrencyID { get; set; }
        public virtual Currency? Currency { get; set; }

        public Boolean Salesperson { get; set; }
        public Boolean IsActive { get; set; }

        [Required]
        [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public virtual Organization? Organization { get; set; }

        //public virtual Organization? Organization { get; set; }
        //public virtual Address? Address { get; set; }
        //public virtual Department? Department { get; set; }
        //public virtual Position? Position { get; set; }
        //public virtual Activity? Activity { get; set; }

        //public virtual Currency? Currency { get; set; }

    }
}
