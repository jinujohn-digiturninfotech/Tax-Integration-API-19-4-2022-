﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace TaxIntegrationLatest.API.Models
{
    public class UnitOfMeasure
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter UnitOfMeasure ")]
        [Column(TypeName = "nvarchar(100)")]
        public string? UnitDesc { get; set; }
        [Required(ErrorMessage = "Please Enter UnitFactor ")]
        [Column(TypeName = "nvarchar(50)")]
        public string? UnitFactor { get; set; }
        
        [Required]
        [Column(TypeName = "char(5)")]
        public string? UnitAbbreviation { get; set; }
        [Required]

       // [ForeignKey("Organization")]
        public int OrganizationID { get; set; }
        public Boolean IsActive { get; set; }
       // [JsonIgnore]
        //public virtual Organization? Organization { get; set; }

    }
}
